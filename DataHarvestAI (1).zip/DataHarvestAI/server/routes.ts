import express, { type Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertUserSchema, insertMentorSchema, insertTaskSchema, insertRuleSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Middleware for handling errors
  const errorHandler = (fn: (req: Request, res: Response, next: NextFunction) => Promise<any>) => {
    return async (req: Request, res: Response, next: NextFunction) => {
      try {
        await fn(req, res, next);
      } catch (error) {
        console.error(error);
        res.status(500).json({ error: "Internal server error" });
      }
    };
  };

  // Health check endpoint
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok' });
  });
  
  // Version info
  app.get('/api/version', (req, res) => {
    res.json({ 
      version: '1.0.0',
      name: 'Solo Leveling System'
    });
  });

  // User routes
  app.post('/api/users', errorHandler(async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      const user = await storage.createUser(userData);
      res.status(201).json(user);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: error.errors });
      } else {
        throw error;
      }
    }
  }));

  app.get('/api/users/:id', errorHandler(async (req, res) => {
    const userId = parseInt(req.params.id);
    const user = await storage.getUser(userId);
    
    if (!user) {
      res.status(404).json({ error: "User not found" });
      return;
    }
    
    res.json(user);
  }));

  // Mentor routes
  app.get('/api/users/:userId/mentors', errorHandler(async (req, res) => {
    const userId = parseInt(req.params.userId);
    const mentors = await storage.getMentorsByUserId(userId);
    res.json(mentors);
  }));

  app.post('/api/mentors', errorHandler(async (req, res) => {
    try {
      const mentorData = insertMentorSchema.parse(req.body);
      const mentor = await storage.createMentor(mentorData);
      res.status(201).json(mentor);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: error.errors });
      } else {
        throw error;
      }
    }
  }));

  app.put('/api/mentors/:id', errorHandler(async (req, res) => {
    const mentorId = parseInt(req.params.id);
    const updates = req.body;
    const mentor = await storage.updateMentor(mentorId, updates);
    
    if (!mentor) {
      res.status(404).json({ error: "Mentor not found" });
      return;
    }
    
    res.json(mentor);
  }));

  app.delete('/api/mentors/:id', errorHandler(async (req, res) => {
    const mentorId = parseInt(req.params.id);
    await storage.deleteMentor(mentorId);
    res.status(204).send();
  }));

  // Task routes
  app.get('/api/users/:userId/tasks', errorHandler(async (req, res) => {
    const userId = parseInt(req.params.userId);
    const tasks = await storage.getTasksByUserId(userId);
    res.json(tasks);
  }));

  app.post('/api/tasks', errorHandler(async (req, res) => {
    try {
      const taskData = insertTaskSchema.parse(req.body);
      const task = await storage.createTask(taskData);
      res.status(201).json(task);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: error.errors });
      } else {
        throw error;
      }
    }
  }));

  app.put('/api/tasks/:id/complete', errorHandler(async (req, res) => {
    const taskId = parseInt(req.params.id);
    const task = await storage.completeTask(taskId);
    
    if (!task) {
      res.status(404).json({ error: "Task not found" });
      return;
    }
    
    res.json(task);
  }));

  app.delete('/api/users/:userId/tasks', errorHandler(async (req, res) => {
    const userId = parseInt(req.params.userId);
    await storage.resetTasks(userId);
    res.status(204).send();
  }));

  // Rule routes
  app.get('/api/users/:userId/rules', errorHandler(async (req, res) => {
    const userId = parseInt(req.params.userId);
    const rules = await storage.getRulesByUserId(userId);
    res.json(rules);
  }));

  app.post('/api/rules', errorHandler(async (req, res) => {
    try {
      const ruleData = insertRuleSchema.parse(req.body);
      const rule = await storage.createRule(ruleData);
      res.status(201).json(rule);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: error.errors });
      } else {
        throw error;
      }
    }
  }));

  app.put('/api/rules/:id', errorHandler(async (req, res) => {
    const ruleId = parseInt(req.params.id);
    const updates = req.body;
    const rule = await storage.updateRule(ruleId, updates);
    
    if (!rule) {
      res.status(404).json({ error: "Rule not found" });
      return;
    }
    
    res.json(rule);
  }));

  app.delete('/api/rules/:id', errorHandler(async (req, res) => {
    const ruleId = parseInt(req.params.id);
    await storage.deleteRule(ruleId);
    res.status(204).send();
  }));

  const httpServer = createServer(app);
  return httpServer;
}
