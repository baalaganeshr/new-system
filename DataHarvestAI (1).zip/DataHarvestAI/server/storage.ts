import { 
  users, type User, type InsertUser,
  mentors, type Mentor, type InsertMentor,
  tasks, type Task, type InsertTask,
  rules, type Rule, type InsertRule
} from "@shared/schema";
import { db } from "./db";
import { eq, and } from "drizzle-orm";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Mentor methods
  getMentorsByUserId(userId: number): Promise<Mentor[]>;
  createMentor(mentor: InsertMentor): Promise<Mentor>;
  updateMentor(id: number, updates: Partial<Omit<Mentor, "id" | "userId" | "createdAt">>): Promise<Mentor | undefined>;
  deleteMentor(id: number): Promise<boolean>;
  
  // Task methods
  getTasksByUserId(userId: number): Promise<Task[]>;
  createTask(task: InsertTask): Promise<Task>;
  completeTask(id: number): Promise<Task | undefined>;
  resetTasks(userId: number): Promise<boolean>;
  
  // Rule methods
  getRulesByUserId(userId: number): Promise<Rule[]>;
  createRule(rule: InsertRule): Promise<Rule>;
  updateRule(id: number, updates: Partial<Omit<Rule, "id" | "userId" | "createdAt">>): Promise<Rule | undefined>;
  deleteRule(id: number): Promise<boolean>;
}

export class DatabaseStorage implements IStorage {
  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values({
        ...insertUser,
        currentRank: "E1",
        currentXp: 0
      })
      .returning();
    return user;
  }
  
  // Mentor methods
  async getMentorsByUserId(userId: number): Promise<Mentor[]> {
    return db.select().from(mentors).where(eq(mentors.userId, userId));
  }
  
  async createMentor(mentor: InsertMentor): Promise<Mentor> {
    const [newMentor] = await db
      .insert(mentors)
      .values(mentor)
      .returning();
    return newMentor;
  }
  
  async updateMentor(id: number, updates: Partial<Omit<Mentor, "id" | "userId" | "createdAt">>): Promise<Mentor | undefined> {
    const [updatedMentor] = await db
      .update(mentors)
      .set(updates)
      .where(eq(mentors.id, id))
      .returning();
    return updatedMentor;
  }
  
  async deleteMentor(id: number): Promise<boolean> {
    const result = await db
      .delete(mentors)
      .where(eq(mentors.id, id));
    return true; // In Drizzle, delete doesn't return a count so we assume success
  }
  
  // Task methods
  async getTasksByUserId(userId: number): Promise<Task[]> {
    return db.select().from(tasks).where(eq(tasks.userId, userId));
  }
  
  async createTask(task: InsertTask): Promise<Task> {
    const [newTask] = await db
      .insert(tasks)
      .values(task)
      .returning();
    return newTask;
  }
  
  async completeTask(id: number): Promise<Task | undefined> {
    const [updatedTask] = await db
      .update(tasks)
      .set({ 
        isCompleted: true,
        completedAt: new Date()
      })
      .where(eq(tasks.id, id))
      .returning();
    return updatedTask;
  }
  
  async resetTasks(userId: number): Promise<boolean> {
    await db
      .delete(tasks)
      .where(
        and(
          eq(tasks.userId, userId),
          eq(tasks.isCompleted, true)
        )
      );
    return true;
  }
  
  // Rule methods
  async getRulesByUserId(userId: number): Promise<Rule[]> {
    return db.select().from(rules).where(eq(rules.userId, userId));
  }
  
  async createRule(rule: InsertRule): Promise<Rule> {
    const [newRule] = await db
      .insert(rules)
      .values(rule)
      .returning();
    return newRule;
  }
  
  async updateRule(id: number, updates: Partial<Omit<Rule, "id" | "userId" | "createdAt">>): Promise<Rule | undefined> {
    const [updatedRule] = await db
      .update(rules)
      .set(updates)
      .where(eq(rules.id, id))
      .returning();
    return updatedRule;
  }
  
  async deleteRule(id: number): Promise<boolean> {
    await db
      .delete(rules)
      .where(eq(rules.id, id));
    return true;
  }
}

export const storage = new DatabaseStorage();
