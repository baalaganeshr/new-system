import { pgTable, text, serial, integer, boolean, jsonb, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User schema
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  displayName: text("display_name"),
  selectedRankSystem: text("selected_rank_system").default("type_a"),
  currentRank: text("current_rank").default("E1"),
  currentXp: integer("current_xp").default(0),
  responseMode: text("response_mode").default("mixed"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Mentor schema
export const mentors = pgTable("mentors", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  name: text("name").notNull(),
  personalityType: text("personality_type").notNull(),
  function: text("function").notNull(),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

// Task schema
export const tasks = pgTable("tasks", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  mentorId: integer("mentor_id"),
  title: text("title").notNull(),
  description: text("description"),
  xpReward: integer("xp_reward").default(100),
  isCompleted: boolean("is_completed").default(false),
  completedAt: timestamp("completed_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

// User-defined rules schema
export const rules = pgTable("rules", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  ruleText: text("rule_text").notNull(),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  displayName: true,
  selectedRankSystem: true,
  responseMode: true,
});

export const insertMentorSchema = createInsertSchema(mentors).pick({
  userId: true,
  name: true,
  personalityType: true,
  function: true,
  isActive: true,
});

export const insertTaskSchema = createInsertSchema(tasks).pick({
  userId: true,
  mentorId: true,
  title: true,
  description: true,
  xpReward: true,
});

export const insertRuleSchema = createInsertSchema(rules).pick({
  userId: true,
  ruleText: true,
  isActive: true,
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertMentor = z.infer<typeof insertMentorSchema>;
export type Mentor = typeof mentors.$inferSelect;

export type InsertTask = z.infer<typeof insertTaskSchema>;
export type Task = typeof tasks.$inferSelect;

export type InsertRule = z.infer<typeof insertRuleSchema>;
export type Rule = typeof rules.$inferSelect;
