import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AppProvider } from "@/contexts/AppContext";
import Dashboard from "@/pages/Dashboard";
import MentorCreator from "@/pages/MentorCreator";
import DailyMissions from "@/pages/DailyMissions";
import Logbook from "@/pages/Logbook";
import ProgressCharts from "@/pages/ProgressCharts";
import Settings from "@/pages/Settings";
import NotFound from "@/pages/not-found";
import UserSetup from "@/pages/UserSetup";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Dashboard} />
      <Route path="/mentors" component={MentorCreator} />
      <Route path="/missions" component={DailyMissions} />
      <Route path="/logbook" component={Logbook} />
      <Route path="/progress" component={ProgressCharts} />
      <Route path="/settings" component={Settings} />
      <Route path="/setup" component={UserSetup} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AppProvider>
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </AppProvider>
    </QueryClientProvider>
  );
}

export default App;
