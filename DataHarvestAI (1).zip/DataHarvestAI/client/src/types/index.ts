// Rank System Types
export type RankSystemType = 'type_a' | 'type_b' | 'type_c';

export type RankTier = {
  name: string;
  level: number;
  xpRequired: number;
  badge: string;
};

export type RankSystem = {
  id: RankSystemType;
  name: string;
  description: string;
  ranks: RankTier[];
};

// Personality Types
export type PersonalityType = 'strict' | 'friendly' | 'brother' | 'father' | 'commander' | 'captain' | 'assistant';

export type ResponseMode = 'strict' | 'friendly' | 'mixed' | 'silent';

// Function Types
export type MentorFunction = 'health' | 'productivity' | 'ai_tech' | 'mindset';

// Mentor Type
export type Mentor = {
  id: string;
  name: string;
  personalityType: PersonalityType;
  function: MentorFunction;
  isActive: boolean;
  createdAt: string;
};

// Task/Mission Type
export type Task = {
  id: string;
  mentorId?: string;
  title: string;
  description: string;
  xpReward: number;
  isCompleted: boolean;
  completedAt?: string;
  createdAt: string;
  category?: string;
  estimatedTime?: string;
};

// User Rule Type
export type Rule = {
  id: string;
  ruleText: string;
  isActive: boolean;
  createdAt: string;
};

// User Type
export type User = {
  id: string;
  displayName: string;
  selectedRankSystem: RankSystemType;
  currentRank: string;
  currentXp: number;
  responseMode: ResponseMode;
  targetXp: number;
};

// Mentor Message Type
export type MentorMessage = {
  id: string;
  mentorId: string;
  mentorName: string;
  mentorPersonality: PersonalityType;
  message: string;
  isRead: boolean;
  createdAt: string;
};

// Log Entry Type
export type LogEntry = {
  id: string;
  taskId: string;
  taskTitle: string;
  xpGained: number;
  completedAt: string;
  mentorId?: string;
  mentorName?: string;
};

// Progress Data Type
export type ProgressData = {
  date: string;
  xpGained: number;
  tasksCompleted: number;
};

// Theme Type
export type ThemeType = 'dark' | 'light';

// App Context Type
export type AppContextType = {
  user: User | null;
  mentors: Mentor[];
  tasks: Task[];
  completedTasks: Task[];
  rules: Rule[];
  mentorMessages: MentorMessage[];
  logs: LogEntry[];
  progressData: ProgressData[];
  isLevelUpModalOpen: boolean;
  newRank: string;
  theme: ThemeType;
  setUser: (user: User) => void;
  updateUserName: (name: string) => void;
  updateRankSystem: (system: RankSystemType) => void;
  updateResponseMode: (mode: ResponseMode) => void;
  addMentor: (mentor: Omit<Mentor, 'id' | 'createdAt'>) => void;
  updateMentor: (mentor: Mentor) => void;
  deleteMentor: (id: string) => void;
  addTask: (task: Omit<Task, 'id' | 'isCompleted' | 'completedAt' | 'createdAt'>) => void;
  completeTask: (id: string) => void;
  resetTasks: () => void;
  addRule: (rule: Omit<Rule, 'id' | 'createdAt'>) => void;
  updateRule: (rule: Rule) => void;
  deleteRule: (id: string) => void;
  closeLevelUpModal: () => void;
  toggleTheme: () => void;
};
