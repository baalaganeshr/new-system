import { PersonalityType, ResponseMode } from '../types';

// Templates for different personality types
const mentorMessageTemplates: Record<PersonalityType, string[]> = {
  strict: [
    "You need to focus more on consistency. Your performance is not meeting expectations.",
    "I expect better results. You have potential but need to apply yourself.",
    "Your progress is below standard. You must improve your discipline.",
    "This is unacceptable performance. You need to redouble your efforts immediately.",
    "You're falling behind. I expect a significant improvement in the coming days.",
    "Your work ethic needs improvement. Be more disciplined with your tasks.",
    "Results matter more than intentions. Show me results, not excuses.",
    "You're capable of much more. Push yourself harder.",
  ],
  friendly: [
    "Great job on your progress! Keep up the good work!",
    "You're doing well! Just a bit more effort and you'll reach your goals!",
    "I'm impressed by your dedication! You're on the right track!",
    "Nice work today! Remember to take breaks and stay refreshed!",
    "You're making great strides! I'm proud of your commitment!",
    "Fantastic effort! Remember to celebrate your small victories!",
    "You're doing amazingly well! Keep that positive attitude!",
    "I'm loving your progress! Keep that momentum going!",
  ],
  brother: [
    "Hey, not bad! Let's push a bit harder tomorrow, okay?",
    "You're getting there, bro! Just need to stay consistent!",
    "I see you putting in that work! Keep grinding!",
    "We're in this together! I'll help you reach the next level!",
    "You got this! Just focus on one step at a time!",
    "Remember when you thought you couldn't do it? Look at you now!",
    "That's what I'm talking about! Keep that energy up!",
    "I knew you had it in you! Let's keep pushing our limits!",
  ],
  father: [
    "I'm proud of your progress. Keep moving forward with determination.",
    "You've shown real growth. Continue to build on these foundations.",
    "Your dedication is commendable. Remember that consistency is key.",
    "I see your potential. With continued effort, you'll achieve great things.",
    "You're developing good habits. These will serve you well in the future.",
    "Your perseverance impresses me. Never lose that quality.",
    "You're learning important lessons. Apply them to your future challenges.",
    "Your character grows with every challenge you overcome. Keep pressing on.",
  ],
  commander: [
    "Mission progress is acceptable. Proceed with the next objective.",
    "Your performance meets operational standards. Continue with assigned tasks.",
    "Tactical execution successful. Prepare for next deployment.",
    "Progress report received. Maintain current trajectory and velocity.",
    "Objective partially completed. Increase efficiency in next operation.",
    "Strategic goals within reach. Maintain focus and discipline.",
    "Your mission effectiveness is improving. Continue optimizing your approach.",
    "Operation successful. Standby for new directives.",
  ],
  captain: [
    "The team's counting on you. Show them what you're made of!",
    "That's the spirit! You're setting a great example for the team.",
    "Good progress! Remember, we succeed or fail together.",
    "I need your best effort out there. The team needs your contribution.",
    "You're becoming a valuable team member. Keep developing your skills.",
    "That's what leadership looks like! Keep setting the pace.",
    "The team's performance reflects your dedication. Well done.",
    "When you improve, the whole team gets stronger. Keep it up!",
  ],
  assistant: [
    "I've updated your progress metrics. Would you like suggestions for improvement?",
    "Your data indicates steady progress. Can I help optimize your routine?",
    "I've noted your completed tasks. What would you like to prioritize next?",
    "Based on your patterns, mornings seem most productive. Shall we schedule more tasks then?",
    "Your consistency has improved by 23% this week. Well done.",
    "I've prepared an analysis of your performance trends. Would you like to review it?",
    "Task completion rate is above average. Is there an area you'd like to focus on improving?",
    "Your progress data suggests you're ready for more challenging tasks. Shall I adjust your schedule?",
  ],
};

// Templates for different response modes
const responseModeTone: Record<ResponseMode, { success: string[]; failure: string[] }> = {
  strict: {
    success: [
      "Acceptable. But there's still room for improvement.",
      "Task completed. Move on to the next one immediately.",
      "The minimum requirement has been met. Don't expect praise for doing your job.",
      "Completed, but took longer than it should have. Improve your efficiency.",
    ],
    failure: [
      "Unacceptable. This level of failure will not be tolerated.",
      "You've failed to meet even the basic requirements. Do better.",
      "This is far below standard. Reassess your commitment level.",
      "Your performance is inadequate. This reflects poorly on your discipline.",
    ],
  },
  friendly: {
    success: [
      "Wonderful job! You're making great progress!",
      "I'm so happy to see your dedication paying off!",
      "Excellent work! You should be proud of yourself!",
      "You're doing amazingly well! Keep up this fantastic energy!",
    ],
    failure: [
      "Don't worry! Everyone has off days - you'll get it next time!",
      "It's okay to struggle sometimes. The important thing is you tried!",
      "This was challenging, but you'll get better with practice!",
      "Remember, progress isn't always linear. You're still on the right path!",
    ],
  },
  mixed: {
    success: [
      "Good work. Now focus on your next challenge.",
      "Task completed successfully. Keep this momentum going.",
      "Well done. Consistent effort leads to consistent results.",
      "Solid performance. Continue building on this foundation.",
    ],
    failure: [
      "You didn't meet expectations this time. Analyze what went wrong and improve.",
      "This didn't go as planned. Learn from it and do better next time.",
      "You missed the mark here. Reflect on why and make adjustments.",
      "This is below your capability. I expect to see improvement going forward.",
    ],
  },
  silent: {
    success: [
      "...",
      "Task logged.",
      "Progress noted.",
      "Record updated.",
    ],
    failure: [
      "...",
      "Task status: incomplete.",
      "Progress logged.",
      "Record updated.",
    ],
  },
};

// Function to generate mentor messages based on personality type
export function generateMentorMessage(personality: PersonalityType, responseMode: ResponseMode): string {
  // Get random template for the personality type
  const templates = mentorMessageTemplates[personality];
  const randomTemplate = templates[Math.floor(Math.random() * templates.length)];
  
  // Get random tone based on response mode (success or failure randomly for demo)
  const isSuccess = Math.random() > 0.3; // 70% chance of success messages
  const tones = isSuccess ? responseModeTone[responseMode].success : responseModeTone[responseMode].failure;
  const randomTone = tones[Math.floor(Math.random() * tones.length)];
  
  // For silent mode, just return the tone
  if (responseMode === 'silent') {
    return randomTone;
  }
  
  // Combine the template and tone
  return `${randomTemplate} ${randomTone}`;
}

// Function to generate motivational quotes
export function generateMotivationalQuote(): string {
  const quotes = [
    "The only way to do great work is to love what you do.",
    "Success is not final, failure is not fatal: It is the courage to continue that counts.",
    "Believe you can and you're halfway there.",
    "Your time is limited, don't waste it living someone else's life.",
    "It does not matter how slowly you go as long as you do not stop.",
    "The future belongs to those who believe in the beauty of their dreams.",
    "The only limit to our realization of tomorrow will be our doubts of today.",
    "The way to get started is to quit talking and begin doing.",
    "If you can dream it, you can do it.",
    "Don't watch the clock; do what it does. Keep going.",
    "Quality is not an act, it is a habit.",
    "The secret of getting ahead is getting started.",
    "Your talent determines what you can do. Your motivation determines how much you're willing to do.",
    "The harder you work for something, the greater you'll feel when you achieve it.",
    "Dream big and dare to fail.",
  ];
  
  return quotes[Math.floor(Math.random() * quotes.length)];
}
