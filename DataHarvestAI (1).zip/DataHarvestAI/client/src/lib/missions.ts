import { v4 as uuidv4 } from 'uuid';
import { Task, Mentor } from '../types';

// Task categories by mentor function
const taskCategories: Record<string, string[]> = {
  health: ['Exercise', 'Nutrition', 'Wellness', 'Meditation', 'Sleep'],
  productivity: ['Planning', 'Focus', 'Organization', 'Time Management', 'Efficiency'],
  ai_tech: ['Learning', 'Coding', 'Analysis', 'Research', 'Innovation'],
  mindset: ['Mindfulness', 'Growth', 'Resilience', 'Positivity', 'Discipline'],
};

// Task templates by mentor function
const taskTemplates: Record<string, { title: string; description: string; timeEstimate: string; xp: number }[]> = {
  health: [
    {
      title: 'Complete a 30-minute workout',
      description: 'Perform a balanced workout including cardio and strength training for 30 minutes',
      timeEstimate: '30 mins',
      xp: 150
    },
    {
      title: 'Prepare a healthy meal',
      description: 'Cook a balanced meal with protein, vegetables, and whole grains',
      timeEstimate: '45 mins',
      xp: 120
    },
    {
      title: 'Track your water intake',
      description: 'Monitor and reach your daily hydration goal',
      timeEstimate: 'All day',
      xp: 80
    },
    {
      title: 'Practice meditation',
      description: 'Complete a guided meditation session focusing on breathing and mindfulness',
      timeEstimate: '15 mins',
      xp: 100
    },
    {
      title: 'Go for a brisk walk',
      description: 'Take a 20-minute walk outside to get fresh air and light exercise',
      timeEstimate: '20 mins',
      xp: 90
    },
    {
      title: 'Establish a sleep routine',
      description: 'Set up and follow a consistent sleep schedule for better rest',
      timeEstimate: '1 week',
      xp: 200
    },
    {
      title: 'Try a new healthy recipe',
      description: 'Explore a nutritious recipe you never made before',
      timeEstimate: '1 hour',
      xp: 140
    },
    {
      title: 'Complete a flexibility routine',
      description: 'Perform a series of stretches to improve your flexibility',
      timeEstimate: '20 mins',
      xp: 100
    }
  ],
  productivity: [
    {
      title: 'Create a daily plan',
      description: 'Outline your tasks and priorities for the day in order of importance',
      timeEstimate: '15 mins',
      xp: 100
    },
    {
      title: 'Implement the Pomodoro technique',
      description: 'Work for 25 minutes, then take a 5-minute break. Repeat 4 times',
      timeEstimate: '2 hours',
      xp: 150
    },
    {
      title: 'Clear your workspace',
      description: 'Organize and declutter your physical workspace for better focus',
      timeEstimate: '30 mins',
      xp: 120
    },
    {
      title: 'Digital declutter',
      description: 'Organize your digital files, delete unnecessary emails, and clean up your desktop',
      timeEstimate: '45 mins',
      xp: 130
    },
    {
      title: 'Learn a productivity shortcut',
      description: 'Master a new keyboard shortcut or automation to save time',
      timeEstimate: '20 mins',
      xp: 90
    },
    {
      title: 'Complete a task on your list',
      description: 'Tackle that one task you have been putting off',
      timeEstimate: 'Varies',
      xp: 180
    },
    {
      title: 'Track your time usage',
      description: 'Log how you spend your time today to identify inefficiencies',
      timeEstimate: 'All day',
      xp: 120
    },
    {
      title: 'Set up a weekly review system',
      description: 'Create a process to review your progress and plan each week',
      timeEstimate: '1 hour',
      xp: 160
    }
  ],
  ai_tech: [
    {
      title: 'Learn a new programming concept',
      description: 'Study and practice a programming concept you are not familiar with',
      timeEstimate: '1 hour',
      xp: 150
    },
    {
      title: 'Complete a coding challenge',
      description: 'Solve a programming problem to enhance your skills',
      timeEstimate: '45 mins',
      xp: 140
    },
    {
      title: 'Read a technical article',
      description: 'Study a detailed technical article about AI or emerging technology',
      timeEstimate: '30 mins',
      xp: 110
    },
    {
      title: 'Experiment with an AI tool',
      description: 'Try out a new AI tool and document its capabilities',
      timeEstimate: '1 hour',
      xp: 160
    },
    {
      title: 'Optimize existing code',
      description: 'Refactor and improve code you have previously written',
      timeEstimate: '1 hour',
      xp: 170
    },
    {
      title: 'Build a small automation',
      description: 'Create a script that automates a repetitive task',
      timeEstimate: '2 hours',
      xp: 200
    },
    {
      title: 'Watch a technical presentation',
      description: 'View a conference talk or lecture on a relevant tech topic',
      timeEstimate: '45 mins',
      xp: 120
    },
    {
      title: 'Participate in a technical discussion',
      description: 'Engage in a forum or community conversation about technology',
      timeEstimate: '30 mins',
      xp: 100
    }
  ],
  mindset: [
    {
      title: 'Practice gratitude journaling',
      description: 'Write down three things you are grateful for today',
      timeEstimate: '10 mins',
      xp: 80
    },
    {
      title: 'Set a meaningful goal',
      description: 'Define a clear, achievable goal with steps to accomplish it',
      timeEstimate: '30 mins',
      xp: 120
    },
    {
      title: 'Challenge a limiting belief',
      description: 'Identify and reframe a negative thought pattern that is holding you back',
      timeEstimate: '20 mins',
      xp: 110
    },
    {
      title: 'Read a personal development book',
      description: 'Spend time reading a book that helps you grow mentally',
      timeEstimate: '45 mins',
      xp: 130
    },
    {
      title: 'Practice visualization',
      description: 'Visualize yourself successfully achieving your goals',
      timeEstimate: '15 mins',
      xp: 90
    },
    {
      title: 'Learn from failure',
      description: 'Reflect on a recent setback and identify lessons learned',
      timeEstimate: '30 mins',
      xp: 140
    },
    {
      title: 'Perform an act of kindness',
      description: 'Do something helpful for someone else with no expectation of return',
      timeEstimate: 'Varies',
      xp: 100
    },
    {
      title: 'Create a personal mantra',
      description: 'Develop a positive phrase you can repeat to yourself during challenges',
      timeEstimate: '20 mins',
      xp: 90
    }
  ]
};

// Generate missions based on active mentors
export function generateMissions(mentors: Mentor[]): Task[] {
  const activeMentors = mentors.filter(mentor => mentor.isActive);
  
  // If no active mentors, generate generic tasks
  if (activeMentors.length === 0) {
    return generateGenericMissions();
  }
  
  const tasks: Task[] = [];
  
  // Generate 1-2 tasks per active mentor, up to a maximum of 5 total tasks
  activeMentors.forEach(mentor => {
    // Number of tasks to generate for this mentor (1 or 2)
    const numTasks = Math.min(Math.floor(Math.random() * 2) + 1, 5 - tasks.length);
    
    for (let i = 0; i < numTasks && tasks.length < 5; i++) {
      const mentorFunction = mentor.function;
      const templates = taskTemplates[mentorFunction];
      
      // Avoid duplicate tasks by keeping track of used indices
      const usedIndices = new Set();
      let randomIndex: number;
      
      do {
        randomIndex = Math.floor(Math.random() * templates.length);
      } while (usedIndices.has(randomIndex) && usedIndices.size < templates.length);
      
      usedIndices.add(randomIndex);
      
      const template = templates[randomIndex];
      const category = taskCategories[mentorFunction][Math.floor(Math.random() * taskCategories[mentorFunction].length)];
      
      tasks.push({
        id: uuidv4(),
        mentorId: mentor.id,
        title: template.title,
        description: template.description,
        xpReward: template.xp,
        category,
        estimatedTime: template.timeEstimate,
        isCompleted: false,
        createdAt: new Date().toISOString(),
      });
    }
  });
  
  // Fill in with generic tasks if we don't have enough
  while (tasks.length < 3) {
    const genericTask = generateGenericMissions(1)[0];
    tasks.push(genericTask);
  }
  
  return tasks;
}

// Generate generic missions when no mentors are available
function generateGenericMissions(count: number = 3): Task[] {
  const tasks: Task[] = [];
  const functions = Object.keys(taskTemplates);
  
  for (let i = 0; i < count; i++) {
    // Choose a random function
    const randomFunction = functions[Math.floor(Math.random() * functions.length)];
    const templates = taskTemplates[randomFunction];
    const template = templates[Math.floor(Math.random() * templates.length)];
    const category = taskCategories[randomFunction][Math.floor(Math.random() * taskCategories[randomFunction].length)];
    
    tasks.push({
      id: uuidv4(),
      title: template.title,
      description: template.description,
      xpReward: template.xp,
      category,
      estimatedTime: template.timeEstimate,
      isCompleted: false,
      createdAt: new Date().toISOString(),
    });
  }
  
  return tasks;
}