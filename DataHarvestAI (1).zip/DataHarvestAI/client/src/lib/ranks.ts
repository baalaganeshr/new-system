import { RankSystemType } from '../types';

// Define the XP increase per level (25% more than previous level)
const XP_INCREASE_FACTOR = 1.25;

// Base XP required for the first rank in each system
const BASE_XP = {
  type_a: 1000, // E-Rank → D → C → B → A → S
  type_b: 1000, // Bronze → Silver → Gold → Diamond → Master
  type_c: 800,  // Level 1 → Level 2 → ...
};

// Rank definitions for each system
const RANK_SYSTEMS = {
  type_a: [
    { prefix: 'E', levels: 5 },
    { prefix: 'D', levels: 5 },
    { prefix: 'C', levels: 5 },
    { prefix: 'B', levels: 5 },
    { prefix: 'A', levels: 5 },
    { prefix: 'S', levels: 5 },
  ],
  type_b: [
    { prefix: 'Bronze', levels: 4 },
    { prefix: 'Silver', levels: 4 },
    { prefix: 'Gold', levels: 4 },
    { prefix: 'Diamond', levels: 4 },
    { prefix: 'Master', levels: 1 },
  ],
  type_c: [
    // Level system goes from 1 to 30
    { prefix: 'Level', levels: 30 },
  ],
};

// Convert rank string to numeric values
function parseRank(rankSystem: RankSystemType, rank: string): { tier: number; level: number } {
  if (rankSystem === 'type_a' || rankSystem === 'type_b') {
    // Handle tier-based systems (E1, Bronze I, etc.)
    const tierMap = {
      type_a: { 'E': 0, 'D': 1, 'C': 2, 'B': 3, 'A': 4, 'S': 5 },
      type_b: { 'Bronze': 0, 'Silver': 1, 'Gold': 2, 'Diamond': 3, 'Master': 4 },
    };
    
    if (rankSystem === 'type_a') {
      const tier = rank.charAt(0);
      const level = parseInt(rank.substring(1));
      return { tier: tierMap.type_a[tier as keyof typeof tierMap.type_a], level: level - 1 };
    } else {
      // For type_b
      for (const [prefix, tierIdx] of Object.entries(tierMap.type_b)) {
        if (rank.startsWith(prefix)) {
          const levelStr = rank.substring(prefix.length).trim();
          let level = 0;
          
          // Handle Roman numerals or Arabic numerals
          if (levelStr === '') {
            // Master rank might not have a level
            level = 0;
          } else if (levelStr.startsWith(' ')) {
            const romanMap: Record<string, number> = { 'I': 1, 'II': 2, 'III': 3, 'IV': 4 };
            const roman = levelStr.trim();
            level = romanMap[roman] ? romanMap[roman] - 1 : 0;
          } else {
            level = parseInt(levelStr) - 1;
          }
          
          return { tier: tierIdx, level };
        }
      }
      return { tier: 0, level: 0 };
    }
  } else {
    // Handle level-based system (Level 1, Level 2, etc.)
    const level = parseInt(rank.replace('Level ', ''));
    return { tier: 0, level: level - 1 };
  }
}

// Format rank from numeric values
function formatRank(rankSystem: RankSystemType, tier: number, level: number): string {
  if (rankSystem === 'type_a') {
    const prefixes = ['E', 'D', 'C', 'B', 'A', 'S'];
    return `${prefixes[tier]}${level + 1}`;
  } else if (rankSystem === 'type_b') {
    const prefixes = ['Bronze', 'Silver', 'Gold', 'Diamond', 'Master'];
    const romanNumerals = ['I', 'II', 'III', 'IV'];
    
    // Master rank doesn't have levels
    if (prefixes[tier] === 'Master') {
      return 'Master';
    }
    
    return `${prefixes[tier]} ${romanNumerals[level]}`;
  } else {
    // type_c
    return `Level ${level + 1}`;
  }
}

// Calculate total XP required for a specific rank
function calculateRequiredXp(rankSystem: RankSystemType, tier: number, level: number): number {
  let totalXp = 0;
  const systemInfo = RANK_SYSTEMS[rankSystem];
  
  // Sum XP for all previous tiers
  for (let t = 0; t < tier; t++) {
    for (let l = 0; l < systemInfo[t].levels; l++) {
      totalXp += Math.floor(BASE_XP[rankSystem] * Math.pow(XP_INCREASE_FACTOR, t * systemInfo[t].levels + l));
    }
  }
  
  // Add XP for levels in current tier
  for (let l = 0; l < level; l++) {
    totalXp += Math.floor(BASE_XP[rankSystem] * Math.pow(XP_INCREASE_FACTOR, tier * systemInfo[tier].levels + l));
  }
  
  return totalXp;
}

// Calculate XP needed for next rank
function calculateNextRankXp(rankSystem: RankSystemType, tier: number, level: number): number {
  const systemInfo = RANK_SYSTEMS[rankSystem];
  
  // Check if we're at the maximum rank
  if (tier >= systemInfo.length - 1 && level >= systemInfo[tier].levels - 1) {
    return 0; // Max rank reached
  }
  
  return Math.floor(BASE_XP[rankSystem] * Math.pow(XP_INCREASE_FACTOR, tier * systemInfo[tier].levels + level));
}

// Get the next rank
function getNextRank(rankSystem: RankSystemType, tier: number, level: number): { tier: number; level: number } {
  const systemInfo = RANK_SYSTEMS[rankSystem];
  
  // Check if we're at the maximum rank
  if (tier >= systemInfo.length - 1 && level >= systemInfo[tier].levels - 1) {
    return { tier, level }; // Stay at max rank
  }
  
  // Check if we need to move to the next tier
  if (level >= systemInfo[tier].levels - 1) {
    return { tier: tier + 1, level: 0 };
  } else {
    return { tier, level: level + 1 };
  }
}

// Calculate current rank based on XP
export function calculateXp(rankSystem: RankSystemType, currentRank: string, newXp: number) {
  const { tier, level } = parseRank(rankSystem, currentRank);
  const currentRequiredXp = calculateRequiredXp(rankSystem, tier, level);
  const nextRankXp = calculateNextRankXp(rankSystem, tier, level);
  
  // If we haven't reached the XP for the next rank, stay at current rank
  if (newXp < currentRequiredXp + nextRankXp) {
    return {
      currentRank,
      currentXp: newXp,
      targetXp: currentRequiredXp + nextRankXp,
      hasLeveledUp: false,
    };
  }
  
  // We've leveled up, calculate the new rank
  let tempTier = tier;
  let tempLevel = level;
  let tempXp = newXp;
  let tempRequiredXp = currentRequiredXp;
  let hasLeveledUp = false;
  
  // Keep leveling up as long as we have enough XP
  while (true) {
    const nextXpNeeded = calculateNextRankXp(rankSystem, tempTier, tempLevel);
    
    // If we're at max rank or don't have enough XP for next rank
    if (nextXpNeeded === 0 || tempXp < tempRequiredXp + nextXpNeeded) {
      break;
    }
    
    // Level up
    hasLeveledUp = true;
    tempRequiredXp += nextXpNeeded;
    const nextRank = getNextRank(rankSystem, tempTier, tempLevel);
    tempTier = nextRank.tier;
    tempLevel = nextRank.level;
  }
  
  // Calculate XP for the next rank
  const newTargetXp = tempRequiredXp + calculateNextRankXp(rankSystem, tempTier, tempLevel);
  
  return {
    currentRank: formatRank(rankSystem, tempTier, tempLevel),
    currentXp: newXp,
    targetXp: newTargetXp,
    hasLeveledUp,
  };
}

// Get rank details for display
export function getRankDetails(rankSystem: RankSystemType, currentXp: number = 0, initialLevel: number = 0) {
  // Initialize with first rank
  let currentRank = '';
  
  if (rankSystem === 'type_a') {
    currentRank = 'E1';
  } else if (rankSystem === 'type_b') {
    currentRank = 'Bronze I';
  } else {
    currentRank = 'Level 1';
  }
  
  // If we have initial XP, calculate the correct rank
  if (currentXp > 0 || initialLevel > 0) {
    const result = calculateXp(rankSystem, currentRank, currentXp);
    currentRank = result.currentRank;
    return result;
  }
  
  // For new users, just return the first rank details
  const { tier, level } = parseRank(rankSystem, currentRank);
  const targetXp = calculateNextRankXp(rankSystem, tier, level);
  
  return {
    currentRank,
    currentXp,
    targetXp,
    hasLeveledUp: false,
  };
}

// Get rank display information
export function getRankDisplayInfo(rankSystem: RankSystemType, rank: string) {
  const { tier, level } = parseRank(rankSystem, rank);
  
  // Map ranks to badge colors and descriptions
  const rankColors = {
    type_a: [
      'gray-500', // E
      'green-500', // D
      'blue-500', // C
      'purple-500', // B
      'yellow-500', // A
      'red-500', // S
    ],
    type_b: [
      'yellow-700', // Bronze
      'gray-400', // Silver
      'yellow-500', // Gold
      'cyan-400', // Diamond
      'purple-500', // Master
    ],
    type_c: [
      'blue-500', // All levels use the same color
    ],
  };
  
  const rankDescriptions = {
    type_a: [
      'Beginner', // E
      'Novice', // D
      'Intermediate', // C
      'Advanced', // B
      'Expert', // A
      'Master', // S
    ],
    type_b: [
      'Beginner', // Bronze
      'Intermediate', // Silver
      'Advanced', // Gold
      'Expert', // Diamond
      'Master', // Master
    ],
    type_c: [
      'Hunter', // All levels use the same description
    ],
  };
  
  // Make sure tier is valid and exists in the RANK_SYSTEMS
  const validTier = Math.min(tier, RANK_SYSTEMS[rankSystem].length - 1);
  const tierInfo = RANK_SYSTEMS[rankSystem][validTier];
  const maxLevels = tierInfo?.levels || 1; // Fallback to 1 if levels is undefined
  
  return {
    color: rankColors[rankSystem][validTier],
    description: rankDescriptions[rankSystem][validTier],
    progress: level / maxLevels,
  };
}

// Get all ranks for a system
export function getAllRanks(rankSystem: RankSystemType) {
  const systemInfo = RANK_SYSTEMS[rankSystem];
  const ranks = [];
  
  for (let tier = 0; tier < systemInfo.length; tier++) {
    for (let level = 0; level < systemInfo[tier].levels; level++) {
      ranks.push(formatRank(rankSystem, tier, level));
    }
  }
  
  return ranks;
}

// Get rank system information
export function getRankSystemInfo(rankSystem: RankSystemType) {
  const systemNames = {
    type_a: 'Hunter Ranks',
    type_b: 'League System',
    type_c: 'Level System',
  };
  
  const systemDescriptions = {
    type_a: 'Progress from E-Rank to S-Rank with 5 levels each',
    type_b: 'Climb from Bronze to Master with 4 tiers each (except Master)',
    type_c: 'Simple level-based progression from Level 1 to 30',
  };
  
  return {
    name: systemNames[rankSystem],
    description: systemDescriptions[rankSystem],
  };
}
