import React, { useState, useEffect } from 'react';
import { useAppContext } from '@/contexts/AppContext';
import GlassCard from '@/components/common/GlassCard';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { AlertTriangle, BadgeCheck, Save, AlertCircle, Trophy, Loader2 } from 'lucide-react';
import { toast } from '@/hooks/use-toast';
import { RankSystemType } from '@/types';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { 
  Alert,
  AlertDescription,
  AlertTitle
} from "@/components/ui/alert";
import { getRankSystemInfo } from '@/lib/ranks';

const RankSettings: React.FC = () => {
  const { user, updateRankSystem } = useAppContext();
  const [selectedSystem, setSelectedSystem] = useState<RankSystemType>(
    user?.selectedRankSystem || 'type_a'
  );
  const [showConfirmDialog, setShowConfirmDialog] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [selectedCard, setSelectedCard] = useState<string | null>(null);
  
  useEffect(() => {
    // Initialize selected card for animation effect
    if (user?.selectedRankSystem) {
      setSelectedCard(user.selectedRankSystem);
    }
  }, [user?.selectedRankSystem]);
  
  const rankSystems = [
    {
      id: 'type_a' as RankSystemType,
      name: 'Hunter Ranks',
      description: 'Progress from E-Rank to S-Rank with 5 levels each',
      example: 'E1 → D1 → C1 → B1 → A1 → S1',
      color: 'from-blue-600 to-purple-600',
    },
    {
      id: 'type_b' as RankSystemType,
      name: 'League System',
      description: 'Climb from Bronze to Master with tiered levels',
      example: 'Bronze I → Silver I → Gold I → Diamond I → Master',
      color: 'from-yellow-700 to-yellow-400',
    },
    {
      id: 'type_c' as RankSystemType,
      name: 'Level System',
      description: 'Simple level-based progression from Level 1 to 30',
      example: 'Level 1 → Level 2 → ... → Level 30',
      color: 'from-green-600 to-teal-500',
    },
  ];
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      if (!user) {
        setError("User profile not found. Please refresh the page.");
        return;
      }
      
      if (selectedSystem === user.selectedRankSystem) {
        toast({
          title: "No changes made",
          description: "You're already using this rank system.",
        });
        return;
      }
      
      // Show confirmation dialog before resetting progress
      setShowConfirmDialog(true);
    } catch (err) {
      setError("An error occurred. Please try again.");
    }
  };
  
  const confirmSystemChange = () => {
    if (!user) return;
    
    setLoading(true);
    
    try {
      // Get the info about the new rank system for the toast message
      const rankInfo = getRankSystemInfo(selectedSystem);
      
      // Small delay for visual feedback
      setTimeout(() => {
        updateRankSystem(selectedSystem);
        setShowConfirmDialog(false);
        setLoading(false);
        
        // Visual feedback with more detailed toast
        toast({
          title: "Rank system updated",
          description: `Your rank system has been changed to ${rankInfo.name}. Progress has been reset.`,
        });
        
        // Add animation effect
        setSelectedCard(selectedSystem);
      }, 800);
    } catch (err) {
      setError("Failed to update rank system. Please try again.");
      setLoading(false);
      setShowConfirmDialog(false);
    }
  };
  
  // Handle card selection with animation
  const handleCardClick = (systemId: RankSystemType) => {
    setSelectedCard(systemId);
    setSelectedSystem(systemId);
  };
  
  // Show error state if no user data is available
  if (!user) {
    return (
      <GlassCard className="p-6">
        <Alert variant="destructive" className="mb-4">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Error Loading Profile</AlertTitle>
          <AlertDescription>
            Unable to load user profile data. Please try refreshing the page.
          </AlertDescription>
        </Alert>
        <Button 
          onClick={() => window.location.reload()}
          className="w-full"
        >
          Refresh Page
        </Button>
      </GlassCard>
    );
  }
  
  return (
    <>
      <GlassCard className="p-6">
        <h2 className="text-xl font-semibold text-foreground mb-4 flex items-center">
          <Trophy className="h-5 w-5 mr-2 text-primary" />
          Rank System
        </h2>
        
        {error && (
          <Alert variant="destructive" className="mb-4">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Error</AlertTitle>
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}
        
        <div className="mb-6 p-3 border border-yellow-500/30 bg-yellow-500/5 rounded-md flex items-start">
          <AlertTriangle className="text-yellow-500 h-5 w-5 mr-2 mt-0.5 flex-shrink-0" />
          <p className="text-sm text-foreground/90">
            Changing your rank system will reset your current rank and XP progress.
            This action cannot be undone.
          </p>
        </div>
        
        <form onSubmit={handleSubmit}>
          <div className="space-y-6">
            <div>
              <Label className="text-foreground mb-3 block">
                Select your rank progression system
              </Label>
              <div className="space-y-3">
                {rankSystems.map((system) => (
                  <div
                    key={system.id}
                    className={`border rounded-lg p-4 cursor-pointer transition-all duration-300 
                      ${selectedSystem === system.id ? 'border-primary bg-primary/10 shadow-md' : 'border-border hover:border-primary/30'}
                      ${selectedCard === system.id ? 'transform scale-[1.01]' : ''}
                    `}
                    onClick={() => handleCardClick(system.id)}
                  >
                    <div className="flex items-center">
                      <div className={`w-5 h-5 rounded-full bg-gradient-to-r ${system.color} mr-3 transition-transform duration-300 ${selectedSystem === system.id ? 'scale-125' : ''}`}></div>
                      <input
                        type="radio"
                        name="rankSystem"
                        checked={selectedSystem === system.id}
                        onChange={() => {}}
                        className="h-4 w-4 text-primary rounded-full mr-2"
                      />
                      <span className="ml-2 font-medium text-foreground">{system.name}</span>
                    </div>
                    <p className="mt-2 text-sm text-muted-foreground">{system.description}</p>
                    <p className="mt-2 text-xs font-mono text-primary/70 bg-primary/5 p-1.5 rounded">{system.example}</p>
                    {user.selectedRankSystem === system.id && (
                      <div className="mt-2 text-xs bg-secondary/10 text-secondary rounded-md px-2 py-1 inline-block">
                        Currently Selected
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
            
            <div className="pt-4 border-t border-border">
              <Button 
                type="submit"
                className="bg-primary hover:bg-primary/90 transition-all duration-300 transform hover:scale-105 active:scale-95"
                disabled={selectedSystem === user.selectedRankSystem}
              >
                <BadgeCheck className="h-4 w-4 mr-2" />
                Save Rank System
              </Button>
            </div>
          </div>
        </form>
      </GlassCard>
      
      {/* Confirmation Dialog */}
      <Dialog open={showConfirmDialog} onOpenChange={setShowConfirmDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center">
              <AlertCircle className="h-5 w-5 text-destructive mr-2" />
              Confirm Rank System Change
            </DialogTitle>
            <DialogDescription>
              <p className="mb-2">
                Changing your rank system will reset your progress. You are currently
                <span className="font-semibold text-foreground"> {user.currentRank} </span> 
                with <span className="font-semibold text-foreground">{user.currentXp} XP</span>.
              </p>
              <p className="text-destructive">This action cannot be undone.</p>
            </DialogDescription>
          </DialogHeader>
          
          <div className="p-3 border border-border rounded-md bg-background/50 my-2">
            <div className="font-medium">New Rank System:</div>
            <div className="text-primary font-semibold mt-1">
              {rankSystems.find(sys => sys.id === selectedSystem)?.name}
            </div>
            <div className="text-xs text-muted-foreground mt-1">
              {rankSystems.find(sys => sys.id === selectedSystem)?.description}
            </div>
          </div>
          
          <DialogFooter className="flex space-x-2 sm:space-x-0">
            <Button
              variant="outline"
              onClick={() => setShowConfirmDialog(false)}
              disabled={loading}
              className="transition-all duration-300"
            >
              Cancel
            </Button>
            <Button
              variant="destructive"
              onClick={confirmSystemChange}
              disabled={loading}
              className="transition-all duration-300"
            >
              {loading ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Processing...
                </>
              ) : (
                "Reset and Change"
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default RankSettings;
