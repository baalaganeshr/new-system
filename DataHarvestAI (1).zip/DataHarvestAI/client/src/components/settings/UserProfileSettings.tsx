import React, { useState, useEffect } from 'react';
import { useAppContext } from '@/contexts/AppContext';
import GlassCard from '@/components/common/GlassCard';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { UserIcon, Save, Sun, Moon, AlertCircle, Loader2 } from 'lucide-react';
import { toast } from '@/hooks/use-toast';
import { 
  Alert,
  AlertDescription,
  AlertTitle
} from "@/components/ui/alert";

const UserProfileSettings: React.FC = () => {
  const { user, updateUserName, theme, toggleTheme } = useAppContext();
  const [displayName, setDisplayName] = useState(user?.displayName || '');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [animateSwitch, setAnimateSwitch] = useState(false);
  
  // Reset error when user changes inputs
  useEffect(() => {
    if (error) setError(null);
  }, [displayName]);
  
  // Add animation effect to theme toggle
  useEffect(() => {
    const timeout = setTimeout(() => {
      setAnimateSwitch(false);
    }, 500);
    
    return () => clearTimeout(timeout);
  }, [animateSwitch]);
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    try {
      if (!user) {
        setError("User profile not found. Please refresh the page.");
        return;
      }
      
      if (displayName.trim() === '') {
        setError("Please enter a display name.");
        return;
      }
      
      updateUserName(displayName);
      
      // Simulate success with visual feedback
      setTimeout(() => {
        toast({
          title: "Profile updated",
          description: "Your profile has been updated successfully.",
        });
        setLoading(false);
      }, 600);
    } catch (err) {
      setError("An error occurred while updating your profile.");
      setLoading(false);
    }
  };
  
  const handleThemeToggle = () => {
    setAnimateSwitch(true);
    toggleTheme();
    
    // Provide immediate feedback
    toast({
      title: `${theme === 'dark' ? 'Light' : 'Dark'} Mode Activated`,
      description: `Your theme has been switched to ${theme === 'dark' ? 'light' : 'dark'} mode.`,
    });
  };
  
  // Show error state if no user data is available
  if (!user) {
    return (
      <GlassCard className="p-6">
        <Alert variant="destructive" className="mb-4">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Error Loading Profile</AlertTitle>
          <AlertDescription>
            Unable to load user profile data. Please try refreshing the page.
          </AlertDescription>
        </Alert>
        <Button 
          onClick={() => window.location.reload()}
          className="w-full"
        >
          Refresh Page
        </Button>
      </GlassCard>
    );
  }
  
  return (
    <GlassCard className="p-6">
      <h2 className="text-xl font-semibold text-foreground mb-6 flex items-center">
        <UserIcon className="h-5 w-5 mr-2 text-primary" />
        Profile Settings
      </h2>
      
      {error && (
        <Alert variant="destructive" className="mb-4">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}
      
      <form onSubmit={handleSubmit}>
        <div className="space-y-6">
          <div>
            <Label htmlFor="displayName" className="text-foreground">
              Display Name
            </Label>
            <div className="mt-1.5 relative">
              <UserIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground" />
              <Input
                id="displayName"
                placeholder="Your display name"
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                className="pl-10 transition-all duration-300 hover:border-primary focus:border-primary focus:ring-1 focus:ring-primary"
                disabled={loading}
              />
            </div>
            <p className="text-xs text-muted-foreground mt-1.5">
              This is how mentors will address you
            </p>
          </div>
          
          <div className="flex items-center justify-between p-3 rounded-lg border border-border hover:border-primary/50 transition-all duration-300">
            <div className="space-y-0.5">
              <Label className="text-foreground">Theme Mode</Label>
              <p className="text-xs text-muted-foreground">
                Toggle between light and dark theme
              </p>
            </div>
            <div className="flex items-center space-x-2">
              <Sun className={`h-4 w-4 transition-colors duration-300 ${theme === 'light' ? 'text-yellow-500' : 'text-muted-foreground'}`} />
              <Switch 
                checked={theme === 'dark'}
                onCheckedChange={handleThemeToggle}
                className={animateSwitch ? 'animate-pulse' : ''}
              />
              <Moon className={`h-4 w-4 transition-colors duration-300 ${theme === 'dark' ? 'text-primary' : 'text-muted-foreground'}`} />
            </div>
          </div>
          
          <div className="pt-4 border-t border-border">
            <Button 
              type="submit"
              className="bg-primary hover:bg-primary/90 transition-all duration-300 transform hover:scale-105 active:scale-95"
              disabled={loading}
            >
              {loading ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Saving...
                </>
              ) : (
                <>
                  <Save className="h-4 w-4 mr-2" />
                  Save Changes
                </>
              )}
            </Button>
          </div>
        </div>
      </form>
    </GlassCard>
  );
};

export default UserProfileSettings;
