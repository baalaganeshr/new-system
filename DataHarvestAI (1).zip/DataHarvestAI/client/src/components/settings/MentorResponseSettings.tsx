import React, { useState } from 'react';
import { useAppContext } from '@/contexts/AppContext';
import GlassCard from '@/components/common/GlassCard';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { MessageCircle, Save } from 'lucide-react';
import { toast } from '@/hooks/use-toast';
import { ResponseMode } from '@/types';

const MentorResponseSettings: React.FC = () => {
  const { user, updateResponseMode } = useAppContext();
  const [selectedMode, setSelectedMode] = useState<ResponseMode>(
    user?.responseMode || 'mixed'
  );
  
  const responseModes = [
    {
      id: 'strict' as ResponseMode,
      name: 'Strict',
      description: 'Focus on discipline and high standards',
      example: 'Task failed. This level of performance is unacceptable. Reassess your commitment.'
    },
    {
      id: 'friendly' as ResponseMode, 
      name: 'Friendly',
      description: 'Encouraging and supportive feedback',
      example: 'Don\'t worry about missing this task! Everyone struggles sometimes - you\'ll get it next time!'
    },
    {
      id: 'mixed' as ResponseMode,
      name: 'Mixed',
      description: 'Balanced feedback style (recommended)',
      example: 'You missed the mark on this task. Learn from it and do better next time.'
    },
    {
      id: 'silent' as ResponseMode,
      name: 'Silent Observer',
      description: 'Minimal feedback, just track progress',
      example: '...'
    },
  ];
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!user) return;
    
    if (selectedMode === user.responseMode) {
      toast({
        title: "No changes made",
        description: "You're already using this response mode.",
      });
      return;
    }
    
    updateResponseMode(selectedMode);
    
    toast({
      title: "Response mode updated",
      description: "Your mentor response style has been updated.",
    });
  };
  
  if (!user) return null;
  
  return (
    <GlassCard className="p-6">
      <h2 className="text-xl font-semibold text-foreground mb-6 flex items-center">
        <MessageCircle className="h-5 w-5 mr-2 text-primary" />
        Mentor Response Mode
      </h2>
      
      <p className="text-muted-foreground mb-6">
        Choose how mentors should respond to your completed and missed tasks.
        This affects the tone and style of feedback you receive.
      </p>
      
      <form onSubmit={handleSubmit}>
        <div className="space-y-6">
          <div>
            <Label className="text-foreground mb-3 block">
              Select response mode
            </Label>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {responseModes.map((mode) => (
                <div
                  key={mode.id}
                  className={`border rounded-lg p-4 cursor-pointer transition-colors ${
                    selectedMode === mode.id
                      ? 'border-primary bg-primary/10'
                      : 'border-border hover:border-primary/30'
                  }`}
                  onClick={() => setSelectedMode(mode.id)}
                >
                  <div className="flex items-center">
                    <input
                      type="radio"
                      name="responseMode"
                      checked={selectedMode === mode.id}
                      onChange={() => {}}
                      className="h-4 w-4 text-primary rounded-full"
                    />
                    <span className="ml-2 font-medium text-foreground">{mode.name}</span>
                  </div>
                  <p className="mt-1 text-sm text-muted-foreground">{mode.description}</p>
                  <p className="mt-2 text-xs text-foreground/70 italic border-l-2 border-primary/30 pl-2 py-1">
                    "{mode.example}"
                  </p>
                </div>
              ))}
            </div>
          </div>
          
          <div className="pt-4 border-t border-border">
            <Button 
              type="submit"
              className="bg-primary hover:bg-primary/90"
            >
              <Save className="h-4 w-4 mr-2" />
              Save Response Mode
            </Button>
          </div>
        </div>
      </form>
    </GlassCard>
  );
};

export default MentorResponseSettings;
