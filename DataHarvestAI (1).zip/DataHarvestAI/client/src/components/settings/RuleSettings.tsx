import React, { useState } from 'react';
import { useAppContext } from '@/contexts/AppContext';
import GlassCard from '@/components/common/GlassCard';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { ScrollText, Trash2, PlusCircle, Save, Edit, X, Check } from 'lucide-react';
import { toast } from '@/hooks/use-toast';
import { Rule } from '@/types';

const RuleSettings: React.FC = () => {
  const { user, rules, addRule, updateRule, deleteRule } = useAppContext();
  const [ruleText, setRuleText] = useState('');
  const [editingRule, setEditingRule] = useState<string | null>(null);
  const [editText, setEditText] = useState('');
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!user) return;
    
    if (ruleText.trim() === '') {
      toast({
        variant: "destructive",
        title: "Rule required",
        description: "Please enter a rule.",
      });
      return;
    }
    
    addRule({
      ruleText,
      isActive: true,
    });
    
    setRuleText('');
    
    toast({
      title: "Rule added",
      description: "Your new rule has been added.",
    });
  };
  
  const handleDeleteRule = (rule: Rule) => {
    deleteRule(rule.id);
    
    toast({
      title: "Rule deleted",
      description: "The rule has been removed.",
    });
  };
  
  const handleEditRule = (rule: Rule) => {
    setEditingRule(rule.id);
    setEditText(rule.ruleText);
  };
  
  const handleCancelEdit = () => {
    setEditingRule(null);
    setEditText('');
  };
  
  const handleSaveEdit = (rule: Rule) => {
    if (editText.trim() === '') {
      toast({
        variant: "destructive",
        title: "Rule required",
        description: "Please enter a rule.",
      });
      return;
    }
    
    updateRule({
      ...rule,
      ruleText: editText,
    });
    
    setEditingRule(null);
    setEditText('');
    
    toast({
      title: "Rule updated",
      description: "Your rule has been updated.",
    });
  };
  
  const handleToggleRule = (rule: Rule) => {
    updateRule({
      ...rule,
      isActive: !rule.isActive,
    });
    
    toast({
      title: rule.isActive ? "Rule deactivated" : "Rule activated",
      description: rule.isActive 
        ? "The rule has been deactivated." 
        : "The rule has been activated.",
    });
  };
  
  if (!user) return null;
  
  return (
    <GlassCard className="p-6">
      <h2 className="text-xl font-semibold text-foreground mb-6 flex items-center">
        <ScrollText className="h-5 w-5 mr-2 text-primary" />
        System Rules
      </h2>
      
      <p className="text-muted-foreground mb-6">
        Create custom rules for how the system and mentors should behave.
        Rules influence how mentors respond to completed or missed tasks.
      </p>
      
      <form onSubmit={handleSubmit} className="mb-6">
        <div className="space-y-4">
          <div>
            <Label htmlFor="ruleText" className="text-foreground">
              New Rule
            </Label>
            <Textarea
              id="ruleText"
              placeholder="e.g., 'If I skip a task, mentors should respond strictly'"
              value={ruleText}
              onChange={(e) => setRuleText(e.target.value)}
              className="mt-1.5 resize-none"
              rows={3}
            />
          </div>
          
          <Button 
            type="submit"
            className="bg-primary hover:bg-primary/90"
          >
            <PlusCircle className="h-4 w-4 mr-2" />
            Add Rule
          </Button>
        </div>
      </form>
      
      <div className="border-t border-border pt-4">
        <h3 className="text-lg font-medium text-foreground mb-4">Current Rules</h3>
        
        {rules.length === 0 ? (
          <p className="text-muted-foreground italic">
            No rules have been created yet. Add your first rule above.
          </p>
        ) : (
          <div className="space-y-3">
            {rules.map((rule) => (
              <div 
                key={rule.id}
                className={`border rounded-lg p-3 ${
                  rule.isActive ? 'border-border' : 'border-border/50 bg-foreground/5'
                }`}
              >
                {editingRule === rule.id ? (
                  <div className="space-y-2">
                    <Textarea
                      value={editText}
                      onChange={(e) => setEditText(e.target.value)}
                      className="resize-none"
                      rows={2}
                    />
                    <div className="flex justify-end space-x-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={handleCancelEdit}
                      >
                        <X className="h-4 w-4 mr-1" />
                        Cancel
                      </Button>
                      <Button
                        size="sm"
                        onClick={() => handleSaveEdit(rule)}
                      >
                        <Check className="h-4 w-4 mr-1" />
                        Save
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div className="flex items-start justify-between">
                    <p className={`text-sm ${rule.isActive ? 'text-foreground' : 'text-muted-foreground'}`}>
                      {rule.ruleText}
                    </p>
                    <div className="flex space-x-1 ml-2">
                      <Button
                        size="icon"
                        variant="ghost"
                        className="h-8 w-8"
                        onClick={() => handleToggleRule(rule)}
                        title={rule.isActive ? "Deactivate rule" : "Activate rule"}
                      >
                        {rule.isActive ? (
                          <div className="h-4 w-4 rounded-full bg-primary"></div>
                        ) : (
                          <div className="h-4 w-4 rounded-full border-2 border-muted-foreground"></div>
                        )}
                      </Button>
                      <Button
                        size="icon"
                        variant="ghost"
                        className="h-8 w-8 text-muted-foreground hover:text-foreground"
                        onClick={() => handleEditRule(rule)}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button
                        size="icon"
                        variant="ghost"
                        className="h-8 w-8 text-muted-foreground hover:text-destructive"
                        onClick={() => handleDeleteRule(rule)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </GlassCard>
  );
};

export default RuleSettings;
