import React, { useState } from 'react';
import { format } from 'date-fns';
import { LogEntry } from '@/types';
import { Award, Search } from 'lucide-react';
import { Input } from '@/components/ui/input';

interface ActivityListProps {
  logs: LogEntry[];
}

const ActivityList: React.FC<ActivityListProps> = ({ logs }) => {
  const [searchTerm, setSearchTerm] = useState('');
  
  // Group logs by date
  const groupedLogs: { [key: string]: LogEntry[] } = {};
  
  logs.forEach(log => {
    const date = log.completedAt.split('T')[0];
    if (!groupedLogs[date]) {
      groupedLogs[date] = [];
    }
    groupedLogs[date].push(log);
  });
  
  // Filter logs based on search term
  const filteredGroupedLogs: { [key: string]: LogEntry[] } = {};
  
  if (searchTerm.trim() === '') {
    Object.assign(filteredGroupedLogs, groupedLogs);
  } else {
    const term = searchTerm.toLowerCase();
    
    Object.keys(groupedLogs).forEach(date => {
      const filteredLogs = groupedLogs[date].filter(log => 
        log.taskTitle.toLowerCase().includes(term) || 
        (log.mentorName && log.mentorName.toLowerCase().includes(term))
      );
      
      if (filteredLogs.length > 0) {
        filteredGroupedLogs[date] = filteredLogs;
      }
    });
  }
  
  // Sort dates in descending order
  const sortedDates = Object.keys(filteredGroupedLogs).sort((a, b) => 
    new Date(b).getTime() - new Date(a).getTime()
  );
  
  // Format date for display
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const today = new Date();
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    
    if (date.toDateString() === today.toDateString()) {
      return 'Today';
    } else if (date.toDateString() === yesterday.toDateString()) {
      return 'Yesterday';
    } else {
      return format(date, 'MMMM d, yyyy');
    }
  };
  
  // Format time for display
  const formatTime = (dateTimeString: string) => {
    return format(new Date(dateTimeString), 'h:mm a');
  };
  
  return (
    <div>
      <div className="p-4 border-b border-border">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search activities..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-9"
          />
        </div>
      </div>
      
      <div className="max-h-[600px] overflow-y-auto">
        {sortedDates.length > 0 ? (
          sortedDates.map(date => (
            <div key={date}>
              <div className="sticky top-0 bg-card/80 backdrop-blur-md px-5 py-2 border-b border-border">
                <div className="font-medium text-foreground">{formatDate(date)}</div>
              </div>
              
              <div className="divide-y divide-border">
                {filteredGroupedLogs[date].map(log => (
                  <div key={log.id} className="px-5 py-3 hover:bg-foreground/5">
                    <div className="flex items-start">
                      <div className="mt-1 mr-3 bg-primary/10 p-1.5 rounded-full text-primary">
                        <Award className="h-5 w-5" />
                      </div>
                      <div>
                        <div className="font-medium text-foreground">{log.taskTitle}</div>
                        <div className="text-sm text-muted-foreground mt-0.5 flex flex-wrap gap-x-2 items-center">
                          <span>{formatTime(log.completedAt)}</span>
                          <span className="font-medium text-primary">+{log.xpGained} XP</span>
                          {log.mentorName && (
                            <span>From mentor: {log.mentorName}</span>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))
        ) : (
          <div className="p-10 text-center">
            {logs.length === 0 ? (
              <>
                <Award className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-xl font-medium text-foreground mb-2">No Activity Yet</h3>
                <p className="text-muted-foreground mb-4">
                  Complete tasks to build your activity log!
                </p>
              </>
            ) : (
              <>
                <Search className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-xl font-medium text-foreground mb-2">No Results Found</h3>
                <p className="text-muted-foreground">
                  Try adjusting your search term.
                </p>
              </>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default ActivityList;
