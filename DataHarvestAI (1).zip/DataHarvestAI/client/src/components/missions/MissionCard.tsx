import React from 'react';
import { useAppContext } from '@/contexts/AppContext';
import GlassCard from '@/components/common/GlassCard';
import { Task } from '@/types';
import { MoreHorizontal, CheckCircle } from 'lucide-react';
import { motion } from 'framer-motion';

interface MissionCardProps {
  task: Task;
  onComplete: (id: string) => void;
}

const MissionCard: React.FC<MissionCardProps> = ({ task, onComplete }) => {
  const { mentors } = useAppContext();
  
  // Function to get category color
  const getCategoryColor = (category?: string) => {
    if (!category) return 'bg-primary/20 text-primary';
    
    switch (category.toLowerCase()) {
      case 'exercise':
      case 'nutrition':
      case 'wellness':
      case 'meditation':
      case 'sleep':
        return 'bg-green-600/20 text-green-400';
        
      case 'planning':
      case 'focus':
      case 'organization':
      case 'time management':
      case 'efficiency':
        return 'bg-blue-600/20 text-blue-400';
        
      case 'learning':
      case 'coding':
      case 'analysis':
      case 'research':
      case 'innovation':
        return 'bg-purple-600/20 text-purple-400';
        
      case 'mindfulness':
      case 'growth':
      case 'resilience':
      case 'positivity':
      case 'discipline':
        return 'bg-yellow-600/20 text-yellow-400';
        
      default:
        return 'bg-primary/20 text-primary';
    }
  };
  
  // Find mentor name by id
  const getMentorName = (mentorId?: string) => {
    if (!mentorId) return null;
    
    const mentor = mentors.find(m => m.id === mentorId);
    return mentor ? mentor.name : null;
  };
  
  const handleComplete = () => {
    onComplete(task.id);
  };
  
  return (
    <motion.div 
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -10 }}
      transition={{ duration: 0.3 }}
    >
      <GlassCard variant="light" className="p-4">
        <div className="flex items-start">
          <div className="h-5 w-5 mt-0.5 mr-3">
            <input 
              type="checkbox" 
              className="h-5 w-5 rounded border-border text-primary focus:ring-primary focus:ring-offset-0 bg-background"
              onChange={handleComplete}
              checked={task.isCompleted}
            />
          </div>
          <div className="flex-1">
            <h3 className={`font-medium ${task.isCompleted ? 'text-muted-foreground line-through' : 'text-foreground'}`}>
              {task.title}
            </h3>
            <p className={`text-sm mt-1 ${task.isCompleted ? 'text-muted-foreground/70 line-through' : 'text-muted-foreground'}`}>
              {task.description}
            </p>
            <div className="flex flex-wrap items-center mt-3 gap-2">
              <span className={`text-xs ${getCategoryColor(task.category)} py-1 px-2 rounded-full`}>
                {task.category || 'Task'}
              </span>
              <span className="text-xs text-muted-foreground">
                {task.estimatedTime || 'Flexible time'}
              </span>
              {task.mentorId && (
                <span className="text-xs text-primary">
                  From: {getMentorName(task.mentorId)}
                </span>
              )}
              {task.isCompleted && task.completedAt && (
                <span className="text-xs text-green-400 flex items-center">
                  <CheckCircle className="h-3 w-3 mr-1" />
                  Completed
                </span>
              )}
            </div>
          </div>
          <div className="ml-4 flex flex-col items-end">
            <span className="text-xs font-semibold bg-secondary/10 text-secondary rounded-full px-2 py-0.5 mb-2">
              +{task.xpReward} XP
            </span>
            <button className="text-muted-foreground hover:text-foreground">
              <MoreHorizontal className="h-5 w-5" />
            </button>
          </div>
        </div>
      </GlassCard>
    </motion.div>
  );
};

export default MissionCard;
