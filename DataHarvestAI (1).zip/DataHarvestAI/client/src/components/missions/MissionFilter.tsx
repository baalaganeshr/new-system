import React, { useEffect, useState } from 'react';
import { useAppContext } from '@/contexts/AppContext';
import { CheckSquare, Square, Filter } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

interface MissionFilterProps {
  viewMode: 'active' | 'completed';
  onViewModeChange: (mode: 'active' | 'completed') => void;
  categoryFilter: string | null;
  onCategoryFilterChange: (category: string | null) => void;
}

const MissionFilter: React.FC<MissionFilterProps> = ({
  viewMode,
  onViewModeChange,
  categoryFilter,
  onCategoryFilterChange
}) => {
  const { tasks, completedTasks } = useAppContext();
  const [availableCategories, setAvailableCategories] = useState<string[]>([]);
  
  // Extract unique categories from tasks
  useEffect(() => {
    const allTasks = [...tasks, ...completedTasks];
    const categories = allTasks
      .map(task => task.category)
      .filter((category): category is string => !!category)
      .filter((value, index, self) => self.indexOf(value) === index)
      .sort();
    
    setAvailableCategories(categories);
  }, [tasks, completedTasks]);
  
  return (
    <div className="flex flex-wrap gap-3">
      <div className="flex rounded-lg overflow-hidden border border-border">
        <Button
          variant={viewMode === 'active' ? "default" : "ghost"}
          className={viewMode === 'active' ? "rounded-none" : "rounded-none text-muted-foreground"}
          onClick={() => onViewModeChange('active')}
        >
          <CheckSquare className="h-4 w-4 mr-2" />
          Active
        </Button>
        <Button
          variant={viewMode === 'completed' ? "default" : "ghost"}
          className={viewMode === 'completed' ? "rounded-none" : "rounded-none text-muted-foreground"}
          onClick={() => onViewModeChange('completed')}
        >
          <Square className="h-4 w-4 mr-2" />
          Completed
        </Button>
      </div>
      
      {availableCategories.length > 0 && (
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline" className="border-border">
              <Filter className="h-4 w-4 mr-2" />
              {categoryFilter ? `Category: ${categoryFilter}` : 'All Categories'}
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent className="w-56">
            <DropdownMenuLabel>Filter by Category</DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuGroup>
              <DropdownMenuItem 
                className={categoryFilter === null ? "bg-primary/10" : ""}
                onClick={() => onCategoryFilterChange(null)}
              >
                All Categories
              </DropdownMenuItem>
              {availableCategories.map(category => (
                <DropdownMenuItem
                  key={category}
                  className={categoryFilter === category ? "bg-primary/10" : ""}
                  onClick={() => onCategoryFilterChange(category)}
                >
                  {category}
                </DropdownMenuItem>
              ))}
            </DropdownMenuGroup>
          </DropdownMenuContent>
        </DropdownMenu>
      )}
    </div>
  );
};

export default MissionFilter;
