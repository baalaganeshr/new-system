import React, { useState } from 'react';
import { Link, useLocation } from 'wouter';
import { motion } from 'framer-motion';
import { useAppContext } from '@/contexts/AppContext';
import XpBar from '@/components/common/XpBar';
import {
  Home,
  Users,
  BookmarkCheck,
  Book,
  BarChart3,
  Settings,
  Shield,
  Zap,
  Bug,
  Vibrate
} from 'lucide-react';
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from '@/components/ui/button';
import { Switch } from "@/components/ui/switch";
import { toast } from '@/hooks/use-toast';

const Sidebar: React.FC = () => {
  const [location] = useLocation();
  const { user, theme, toggleTheme } = useAppContext();
  const [isDiagnosticsOpen, setIsDiagnosticsOpen] = useState(false);
  const [isFeedbackEnabled, setIsFeedbackEnabled] = useState(false);
  const [lastDiagnostic, setLastDiagnostic] = useState<string | null>(null);
  
  // Enhanced navigation with diagnostics mode
  const navigation = [
    { name: 'Dashboard', icon: Home, href: '/' },
    { name: 'Mentor Creator', icon: Users, href: '/mentors' },
    { name: 'Daily Missions', icon: BookmarkCheck, href: '/missions' },
    { name: 'Logbook', icon: Book, href: '/logbook' },
    { name: 'Progress Charts', icon: BarChart3, href: '/progress' },
    { name: 'Settings', icon: Settings, href: '/settings' },
  ];
  
  if (!user) return null;
  
  // Get the first letter of the display name for the avatar
  const nameInitial = user.displayName ? user.displayName.charAt(0).toUpperCase() : 'U';
  
  // Enable haptic/sound feedback
  const handleNavClick = (name: string) => {
    if (isFeedbackEnabled) {
      // Haptic feedback if available
      if (navigator.vibrate) {
        navigator.vibrate(50);
      }
      
      // Play a subtle click sound
      const audio = new Audio();
      audio.src = "data:audio/mp3;base64,SUQzAwAAAAAAIlRJVDIAAAA/AAAATEFNRSAzLjEwMGEVAAAAAAAAAAAAAA==";
      audio.volume = 0.2;
      audio.play().catch(e => console.error('Audio feedback failed:', e));
      
      // Log diagnostics
      setLastDiagnostic(`Navigation: ${name} at ${new Date().toISOString()}`);
    }
  };
  
  // Run diagnostics tests for theme toggling
  const runThemeTest = () => {
    // Toggle theme and back
    toggleTheme();
    setTimeout(() => {
      toggleTheme();
      setLastDiagnostic(`Theme toggled for test at ${new Date().toISOString()}`);
      
      toast({
        title: "Theme Toggle Test",
        description: "Theme system is functioning correctly.",
      });
    }, 500);
  };
  
  // Run diagnostics tests for XP calculation
  const runXpTest = () => {
    if (!user) return;
    
    setLastDiagnostic(`XP Test: Current=${user.currentXp}, Target=${user.targetXp}, Rank=${user.currentRank}, System=${user.selectedRankSystem}`);
    
    toast({
      title: "XP System Check",
      description: `Rank system is functioning. XP progress: ${Math.round((user.currentXp / user.targetXp) * 100)}%`,
    });
  };
  
  return (
    <>
      <div className="hidden md:flex flex-col w-64 bg-background border-r border-border transition-colors duration-300">
        {/* Logo */}
        <div className="flex items-center justify-center h-16 px-4 border-b border-border">
          <h1 className="text-xl font-bold text-foreground flex items-center gap-2">
            <Shield className="h-6 w-6 text-primary" />
            Solo Leveling
          </h1>
        </div>
        
        {/* User Profile */}
        <div className="flex flex-col items-center p-4 border-b border-border">
          <div className="relative cursor-pointer group" onClick={() => setIsDiagnosticsOpen(true)}>
            <div className="h-16 w-16 rounded-full bg-gradient-to-r from-secondary to-primary flex items-center justify-center text-white text-xl font-bold mb-2 
              transition-all duration-300 transform group-hover:scale-105 shadow-md">
              {nameInitial}
            </div>
            <div className="absolute -bottom-1 -right-1 bg-primary text-xs text-white font-medium rounded-full h-6 w-6 
              flex items-center justify-center border-2 border-background transition-all duration-300 
              group-hover:bg-secondary group-hover:scale-110">
              {user.currentRank.charAt(0)}
            </div>
          </div>
          <h2 className="font-semibold text-foreground mt-2">
            {user.displayName || 'Hunter'}
          </h2>
          <div className="text-xs text-muted-foreground mt-1">
            {user.currentRank}
          </div>
          
          {/* XP Bar */}
          <div className="w-full mt-4">
            <XpBar 
              currentXp={user.currentXp} 
              targetXp={user.targetXp} 
              rankName={user.currentRank}
              showAnimation={true}
            />
          </div>
        </div>
        
        {/* Navigation */}
        <nav className="flex-1 overflow-y-auto py-4">
          <ul className="space-y-1 px-2">
            {navigation.map((item) => {
              const isActive = item.href === location;
              
              return (
                <li key={item.name}>
                  <Link href={item.href}>
                    <div
                      className={`flex items-center gap-3 px-4 py-2.5 rounded-lg font-medium transition-all duration-200
                        relative cursor-pointer ${
                        isActive 
                          ? 'text-foreground' 
                          : 'text-muted-foreground hover:text-foreground hover:bg-foreground/5'
                      }`}
                      onClick={() => handleNavClick(item.name)}
                    >
                      {isActive && (
                        <motion.div
                          layoutId="sidebar-active-item"
                          className="absolute inset-0 bg-primary/20 rounded-lg -z-10"
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          exit={{ opacity: 0 }}
                          transition={{ duration: 0.2 }}
                        />
                      )}
                      <item.icon className={`h-5 w-5 transition-transform duration-200 ${isActive ? 'scale-110' : ''}`} />
                      {item.name}
                    </div>
                  </Link>
                </li>
              );
            })}
          </ul>
          
          {/* System Diagnostics Button */}
          <div className="mt-4 px-2">
            <button
              className="w-full flex items-center gap-3 px-4 py-2.5 rounded-lg font-medium transition-all duration-200
                text-muted-foreground hover:text-foreground border border-border/50 hover:border-primary/50
                hover:bg-foreground/5 group"
              onClick={() => setIsDiagnosticsOpen(true)}
            >
              <Bug className="h-5 w-5 group-hover:text-primary transition-colors duration-200" />
              System Diagnostics
            </button>
          </div>
        </nav>
      </div>
      
      {/* System Diagnostics Dialog */}
      <Dialog open={isDiagnosticsOpen} onOpenChange={setIsDiagnosticsOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center">
              <Zap className="h-5 w-5 text-primary mr-2" />
              System Diagnostics Mode
            </DialogTitle>
            <DialogDescription>
              Test and verify system features. This mode helps diagnose issues and check functionality.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-2">
            {/* Haptic Feedback Toggle */}
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <div className="flex items-center">
                  <Vibrate className="h-4 w-4 mr-2 text-muted-foreground" />
                  <span className="font-medium">Haptic/Sound Feedback</span>
                </div>
                <p className="text-xs text-muted-foreground">
                  Enable vibration and sound on interactions
                </p>
              </div>
              <Switch
                checked={isFeedbackEnabled}
                onCheckedChange={setIsFeedbackEnabled}
              />
            </div>
            
            {/* Diagnostic Actions */}
            <div className="border border-border rounded-md divide-y divide-border">
              <div className="p-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <div className="mr-3 h-8 w-8 rounded-full bg-primary/20 flex items-center justify-center">
                      <Settings className="h-4 w-4 text-primary" />
                    </div>
                    <span>Theme System</span>
                  </div>
                  <Button size="sm" variant="outline" onClick={runThemeTest}>
                    Test
                  </Button>
                </div>
              </div>
              
              <div className="p-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <div className="mr-3 h-8 w-8 rounded-full bg-primary/20 flex items-center justify-center">
                      <Zap className="h-4 w-4 text-primary" />
                    </div>
                    <span>XP Calculation</span>
                  </div>
                  <Button size="sm" variant="outline" onClick={runXpTest}>
                    Test
                  </Button>
                </div>
              </div>
            </div>
            
            {/* Last Diagnostic Log */}
            {lastDiagnostic && (
              <div className="p-2 bg-muted/50 rounded-md">
                <p className="text-xs text-muted-foreground font-mono">
                  <span className="text-primary">LOG:</span> {lastDiagnostic}
                </p>
              </div>
            )}
          </div>
          
          <DialogFooter className="flex justify-end">
            <Button 
              onClick={() => setIsDiagnosticsOpen(false)}
              variant="default"
            >
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default Sidebar;