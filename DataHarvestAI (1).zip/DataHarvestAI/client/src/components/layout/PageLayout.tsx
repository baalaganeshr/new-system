import React, { useState } from 'react';
import { motion } from 'framer-motion';
import Sidebar from './Sidebar';
import TopBar from './TopBar';
import LevelUpModal from '@/components/common/LevelUpModal';

interface PageLayoutProps {
  children: React.ReactNode;
  title?: string;
  subtitle?: string;
}

const PageLayout: React.FC<PageLayoutProps> = ({ 
  children, 
  title, 
  subtitle 
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  
  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };
  
  return (
    <div className="flex h-screen overflow-hidden">
      {/* Sidebar - desktop view always, mobile view when toggled */}
      <div className={`${mobileMenuOpen ? 'block' : 'hidden'} md:block fixed md:relative z-20 md:z-auto w-64 h-full`}>
        <Sidebar />
      </div>
      
      {/* Mobile overlay */}
      {mobileMenuOpen && (
        <div 
          className="md:hidden fixed inset-0 bg-black bg-opacity-50 z-10"
          onClick={toggleMobileMenu}
        />
      )}
      
      <div className="flex flex-col flex-1 overflow-hidden">
        <TopBar onMobileMenuToggle={toggleMobileMenu} />
        
        {/* Main Content */}
        <main className="flex-1 overflow-y-auto p-4 md:p-6 bg-background">
          {/* Page Header */}
          {(title || subtitle) && (
            <div className="flex flex-col mb-6">
              {title && (
                <motion.h1 
                  className="text-2xl font-bold text-foreground"
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3 }}
                >
                  {title}
                </motion.h1>
              )}
              {subtitle && (
                <motion.p 
                  className="text-muted-foreground mt-1"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ duration: 0.3, delay: 0.1 }}
                >
                  {subtitle}
                </motion.p>
              )}
            </div>
          )}
          
          {/* Page Content */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
          >
            {children}
          </motion.div>
        </main>
      </div>
      
      {/* Level Up Modal */}
      <LevelUpModal />
    </div>
  );
};

export default PageLayout;
