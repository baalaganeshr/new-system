import React, { useState } from 'react';
import { useAppContext } from '@/contexts/AppContext';
import { Menu, Bell, ChevronDown, Sun, Moon } from 'lucide-react';
import { Link } from 'wouter';

interface TopBarProps {
  onMobileMenuToggle: () => void;
}

const TopBar: React.FC<TopBarProps> = ({ onMobileMenuToggle }) => {
  const { user, mentorMessages, theme, toggleTheme } = useAppContext();
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  
  // Count unread messages
  const unreadCount = mentorMessages.filter(msg => !msg.isRead).length;
  
  // Get the first letter of the display name for the avatar
  const nameInitial = user?.displayName ? user.displayName.charAt(0).toUpperCase() : 'U';
  
  return (
    <header className="bg-background border-b border-border flex items-center justify-between md:justify-end h-16 px-4">
      {/* Mobile Menu Toggle */}
      <button 
        className="md:hidden text-muted-foreground hover:text-foreground"
        onClick={onMobileMenuToggle}
      >
        <Menu className="h-6 w-6" />
      </button>
      
      {/* Right side controls */}
      <div className="flex items-center space-x-4">
        {/* Theme Toggle */}
        <button 
          className="p-1 text-muted-foreground hover:text-foreground"
          onClick={toggleTheme}
        >
          {theme === 'dark' ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
        </button>
        
        {/* Notifications */}
        <button className="relative p-1 text-muted-foreground hover:text-foreground">
          <Bell className="h-5 w-5" />
          {unreadCount > 0 && (
            <div className="absolute top-0 right-0 h-3 w-3 bg-primary rounded-full border border-background"></div>
          )}
        </button>
        
        {/* User Menu */}
        <div className="relative">
          <button 
            className="flex items-center space-x-2"
            onClick={() => setUserMenuOpen(!userMenuOpen)}
          >
            <div className="h-8 w-8 rounded-full bg-secondary flex items-center justify-center text-white text-sm font-bold">
              {nameInitial}
            </div>
            <ChevronDown className="h-4 w-4 text-muted-foreground" />
          </button>
          
          {/* User Dropdown Menu */}
          {userMenuOpen && (
            <div className="absolute right-0 mt-2 w-48 py-2 bg-card rounded-lg shadow-lg border border-border z-10">
              <Link href="/settings">
                <a className="block px-4 py-2 text-sm text-foreground hover:bg-foreground/5">
                  Profile Settings
                </a>
              </Link>
              <Link href="/settings">
                <a className="block px-4 py-2 text-sm text-foreground hover:bg-foreground/5">
                  Rank System
                </a>
              </Link>
              <div className="border-t border-border my-1"></div>
              <button className="w-full text-left block px-4 py-2 text-sm text-foreground hover:bg-foreground/5">
                Sign Out
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};

export default TopBar;
