import React, { useState } from 'react';
import { format, formatDistanceToNow } from 'date-fns';
import { useAppContext } from '@/contexts/AppContext';
import GlassCard from '@/components/common/GlassCard';
import { MoreHorizontal } from 'lucide-react';

const MentorMessages: React.FC = () => {
  const { mentorMessages, mentors } = useAppContext();
  const [isExpanded, setIsExpanded] = useState(false);
  
  // Limit to the 2 most recent messages if not expanded
  const displayedMessages = isExpanded 
    ? mentorMessages 
    : mentorMessages.slice(0, 2);
  
  // Function to get mentor color based on personality type
  const getMentorColor = (personality: string) => {
    switch (personality) {
      case 'strict': return 'border-red-500';
      case 'friendly': return 'border-green-500';
      case 'brother': return 'border-blue-500';
      case 'father': return 'border-yellow-500';
      case 'commander': return 'border-purple-500';
      case 'captain': return 'border-cyan-500';
      case 'assistant': return 'border-gray-500';
      default: return 'border-primary';
    }
  };
  
  // Get mentor initials
  const getMentorInitials = (name: string) => {
    return name
      .split(' ')
      .map(part => part[0])
      .join('')
      .toUpperCase();
  };
  
  // Get mentor background color
  const getMentorBgColor = (personality: string) => {
    switch (personality) {
      case 'strict': return 'bg-red-700';
      case 'friendly': return 'bg-green-700';
      case 'brother': return 'bg-blue-700';
      case 'father': return 'bg-yellow-700';
      case 'commander': return 'bg-purple-700';
      case 'captain': return 'bg-cyan-700';
      case 'assistant': return 'bg-gray-700';
      default: return 'bg-secondary';
    }
  };
  
  return (
    <GlassCard className="p-5">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-semibold text-foreground">Mentor Messages</h2>
        <button className="text-muted-foreground hover:text-foreground">
          <MoreHorizontal className="h-5 w-5" />
        </button>
      </div>
      
      {displayedMessages.length === 0 ? (
        <div className="text-center py-8 text-muted-foreground">
          <p>No mentor messages yet.</p>
          <p className="text-sm mt-2">Create mentors to receive guidance and feedback.</p>
        </div>
      ) : (
        <div className="space-y-4">
          {displayedMessages.map((message) => {
            const mentorColor = getMentorColor(message.mentorPersonality);
            const mentorBgColor = getMentorBgColor(message.mentorPersonality);
            const initials = getMentorInitials(message.mentorName);
            const timeAgo = formatDistanceToNow(new Date(message.createdAt), { addSuffix: true });
            const formattedDate = format(new Date(message.createdAt), 'MMM d, h:mm a');
            
            return (
              <div 
                key={message.id} 
                className={`bg-foreground/5 p-4 rounded-lg border-l-4 ${mentorColor}`}
              >
                <div className="flex items-center mb-3">
                  <div className={`h-8 w-8 rounded-full ${mentorBgColor} flex items-center justify-center text-white text-sm font-bold mr-2`}>
                    {initials}
                  </div>
                  <div>
                    <div className="text-foreground font-medium">{message.mentorName}</div>
                    <div className="text-xs text-muted-foreground capitalize">{message.mentorPersonality} Mentor</div>
                  </div>
                </div>
                <p className="text-foreground/80 text-sm">{message.message}</p>
                <div className="mt-3 flex justify-between items-center">
                  <span className="text-xs text-muted-foreground" title={formattedDate}>{timeAgo}</span>
                  <button className="text-primary hover:text-primary/80 text-xs font-medium">
                    Mark as Read
                  </button>
                </div>
              </div>
            );
          })}
          
          {mentorMessages.length > 2 && (
            <button 
              className="w-full py-2 mt-2 bg-transparent border border-border text-foreground/80 rounded-lg font-medium hover:bg-foreground/5 transition-colors"
              onClick={() => setIsExpanded(!isExpanded)}
            >
              {isExpanded ? 'Show Less' : 'View All Messages'}
            </button>
          )}
        </div>
      )}
    </GlassCard>
  );
};

export default MentorMessages;
