import React from 'react';
import { format } from 'date-fns';
import { useAppContext } from '@/contexts/AppContext';
import GlassCard from '@/components/common/GlassCard';
import { CheckCircle2, Award, TrendingUp } from 'lucide-react';

const StatCards: React.FC = () => {
  const { tasks, completedTasks, progressData, user } = useAppContext();
  
  // Calculate tasks completed today
  const today = format(new Date(), 'yyyy-MM-dd');
  const todayProgressData = progressData.find(item => item.date === today);
  const tasksCompletedToday = todayProgressData?.tasksCompleted || 0;
  
  // Calculate XP gained today
  const xpGainedToday = todayProgressData?.xpGained || 0;
  
  // Calculate remaining XP needed for next level
  const remainingXp = user ? user.targetXp - user.currentXp : 0;
  
  const stats = [
    {
      title: 'Active Tasks',
      value: tasks.length,
      icon: <CheckCircle2 className="h-6 w-6 text-primary" />,
      change: '+' + tasksCompletedToday + ' completed today',
      trend: 'up',
    },
    {
      title: 'XP Gained',
      value: user?.currentXp || 0,
      icon: <Award className="h-6 w-6 text-secondary" />,
      change: '+' + xpGainedToday + ' XP today',
      trend: 'up',
    },
    {
      title: 'Completed Tasks',
      value: completedTasks.length,
      icon: <TrendingUp className="h-6 w-6 text-emerald-400" />,
      change: remainingXp + ' XP to next level',
      trend: 'neutral',
    }
  ];
  
  return (
    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
      {stats.map((stat, index) => (
        <GlassCard key={index} className="p-4" animate>
          <div className="flex items-start justify-between">
            <div>
              <p className="text-muted-foreground text-sm font-medium">{stat.title}</p>
              <h3 className="text-2xl font-bold text-foreground mt-1">{stat.value.toLocaleString()}</h3>
            </div>
            <div className="bg-primary/10 p-2 rounded-lg">
              {stat.icon}
            </div>
          </div>
          <div className="mt-2 flex items-center text-xs">
            <span className={`flex items-center ${
              stat.trend === 'up' 
                ? 'text-green-400' 
                : stat.trend === 'down' 
                  ? 'text-red-400' 
                  : 'text-muted-foreground'
            }`}>
              {stat.trend === 'up' && (
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <polyline points="22 7 13.5 15.5 8.5 10.5 2 17"></polyline>
                  <polyline points="16 7 22 7 22 13"></polyline>
                </svg>
              )}
              {stat.trend === 'down' && (
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <polyline points="22 17 13.5 8.5 8.5 13.5 2 7"></polyline>
                  <polyline points="16 17 22 17 22 11"></polyline>
                </svg>
              )}
              {stat.change}
            </span>
          </div>
        </GlassCard>
      ))}
    </div>
  );
};

export default StatCards;
