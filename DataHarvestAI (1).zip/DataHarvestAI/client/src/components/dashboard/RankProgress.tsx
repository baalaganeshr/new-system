import React from 'react';
import { useAppContext } from '@/contexts/AppContext';
import GlassCard from '@/components/common/GlassCard';
import XpBar from '@/components/common/XpBar';
import { getRankDisplayInfo, getRankSystemInfo } from '@/lib/ranks';

const RankProgress: React.FC = () => {
  const { user } = useAppContext();
  
  if (!user) return null;
  
  const rankInfo = getRankDisplayInfo(user.selectedRankSystem, user.currentRank);
  const systemInfo = getRankSystemInfo(user.selectedRankSystem);
  
  // Get the first letter of rank for the badge
  const rankLetter = user.currentRank.charAt(0);
  
  // Determine rank tiers to display based on the system
  const rankTiers = user.selectedRankSystem === 'type_a' 
    ? ['E', 'D', 'C', 'B', 'A', 'S']
    : user.selectedRankSystem === 'type_b'
      ? ['Bronze', 'Silver', 'Gold', 'Diamond', 'Master']
      : Array.from({ length: 5 }, (_, i) => `${i + 1}`);
  
  const rankLabels = user.selectedRankSystem === 'type_a'
    ? ['Beginner', 'Novice', 'Advanced', 'Expert', 'Master', 'Grandmaster']
    : user.selectedRankSystem === 'type_b'
      ? ['Beginner', 'Intermediate', 'Advanced', 'Expert', 'Master']
      : ['Novice', 'Apprentice', 'Adept', 'Expert', 'Master'];
  
  // Function to check if the rank is current or past
  const isCurrentOrPastRank = (tier: string) => {
    if (user.selectedRankSystem === 'type_a') {
      return tier.charAt(0).charCodeAt(0) <= user.currentRank.charAt(0).charCodeAt(0);
    } else if (user.selectedRankSystem === 'type_b') {
      const tierOrder = { 'Bronze': 0, 'Silver': 1, 'Gold': 2, 'Diamond': 3, 'Master': 4 };
      const currentTier = user.currentRank.split(' ')[0];
      return tierOrder[tier as keyof typeof tierOrder] <= tierOrder[currentTier as keyof typeof tierOrder];
    } else {
      // For level system
      const currentLevel = parseInt(user.currentRank.replace('Level ', ''));
      return parseInt(tier) <= currentLevel;
    }
  };
  
  // Function to check if this is the current rank
  const isCurrentRank = (tier: string) => {
    if (user.selectedRankSystem === 'type_a') {
      return tier.charAt(0) === user.currentRank.charAt(0);
    } else if (user.selectedRankSystem === 'type_b') {
      const currentTier = user.currentRank.split(' ')[0];
      return tier === currentTier;
    } else {
      // For level system
      const currentLevel = parseInt(user.currentRank.replace('Level ', ''));
      return parseInt(tier) === currentLevel;
    }
  };
  
  return (
    <GlassCard className="p-5">
      <h2 className="text-lg font-semibold text-foreground mb-4">Rank Progress</h2>
      
      <div className="flex items-center space-x-4 mb-6">
        <div className={`h-14 w-14 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center text-white font-bold text-xl`}>
          {rankLetter}
        </div>
        <div>
          <div className="text-foreground font-medium">{user.currentRank}</div>
          <div className="text-xs text-muted-foreground">{systemInfo.name} - {rankInfo.description}</div>
        </div>
      </div>
      
      <div className="mb-6">
        <XpBar 
          currentXp={user.currentXp} 
          targetXp={user.targetXp} 
          rankName={`Progress to next level`}
          showAnimation={true}
        />
      </div>
      
      <div className="grid grid-cols-5 gap-2 mb-6">
        {rankTiers.slice(0, 5).map((rank, index) => {
          const isCurrent = isCurrentRank(rank);
          const isPast = !isCurrent && isCurrentOrPastRank(rank);
          
          return (
            <div className="text-center" key={rank}>
              <div 
                className={`h-10 w-10 mx-auto rounded-full flex items-center justify-center text-white font-semibold ${
                  isCurrent
                    ? 'bg-gradient-to-br from-primary to-secondary'
                    : isPast
                      ? 'bg-primary/30'
                      : 'bg-foreground/10'
                }`}
              >
                {user.selectedRankSystem === 'type_c' ? rank : rank.charAt(0)}
              </div>
              <div className={`text-xs mt-1 ${
                isCurrent 
                  ? 'text-primary' 
                  : 'text-muted-foreground'
              }`}>
                {rankLabels[index]}
              </div>
            </div>
          );
        })}
      </div>
      
      <div className="border-t border-border pt-4">
        <div className="text-muted-foreground text-sm mb-2">Next rank benefits:</div>
        <div className="flex items-center text-foreground text-sm">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-primary mr-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <polyline points="20 6 9 17 4 12"></polyline>
          </svg>
          Unlock higher XP rewards
        </div>
        <div className="flex items-center text-foreground text-sm mt-1.5">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-primary mr-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <polyline points="20 6 9 17 4 12"></polyline>
          </svg>
          Access more challenging missions
        </div>
      </div>
    </GlassCard>
  );
};

export default RankProgress;
