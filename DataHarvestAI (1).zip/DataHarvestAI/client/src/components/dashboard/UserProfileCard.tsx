import React from 'react';
import { useAppContext } from '@/contexts/AppContext';
import GlassCard from '@/components/common/GlassCard';
import XpBar from '@/components/common/XpBar';
import { getRankDisplayInfo, getRankSystemInfo } from '@/lib/ranks';

const UserProfileCard: React.FC = () => {
  const { user } = useAppContext();
  
  if (!user) return null;
  
  const rankInfo = getRankDisplayInfo(user.selectedRankSystem, user.currentRank);
  const systemInfo = getRankSystemInfo(user.selectedRankSystem);
  
  // Get the first letter of rank for the badge
  const rankLetter = user.currentRank.charAt(0);
  
  return (
    <GlassCard className="p-5">
      <h2 className="text-lg font-semibold text-foreground mb-4">Rank Progress</h2>
      
      <div className="flex items-center space-x-4 mb-6">
        <div className={`h-14 w-14 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center text-white font-bold text-xl`}>
          {rankLetter}
        </div>
        <div>
          <div className="text-foreground font-medium">{user.currentRank}</div>
          <div className="text-xs text-muted-foreground">{systemInfo.name} - {rankInfo.description}</div>
        </div>
      </div>
      
      <div className="mb-6">
        <XpBar 
          currentXp={user.currentXp} 
          targetXp={user.targetXp} 
          rankName={`Progress to next level`}
          showAnimation={true}
        />
      </div>
      
      <div className="grid grid-cols-5 gap-2 mb-6">
        {['E', 'D', 'C', 'B', 'A'].map((rank, index) => {
          const isCurrentRank = user.currentRank.charAt(0) === rank;
          const isPastRank = 
            user.selectedRankSystem === 'type_a' && 
            rank.charCodeAt(0) < user.currentRank.charAt(0).charCodeAt(0);
          
          return (
            <div className="text-center" key={rank}>
              <div 
                className={`h-10 w-10 mx-auto rounded-full flex items-center justify-center text-white font-semibold ${
                  isCurrentRank
                    ? 'bg-gradient-to-br from-primary to-secondary'
                    : isPastRank
                      ? 'bg-primary/30'
                      : 'bg-foreground/10'
                }`}
              >
                {rank}
              </div>
              <div className={`text-xs mt-1 ${
                isCurrentRank 
                  ? 'text-primary' 
                  : 'text-muted-foreground'
              }`}>
                {index === 0 ? 'Beginner' : 
                 index === 1 ? 'Novice' : 
                 index === 2 ? 'Advanced' : 
                 index === 3 ? 'Expert' : 'Master'}
              </div>
            </div>
          );
        })}
      </div>
      
      <div className="border-t border-border pt-4">
        <div className="text-muted-foreground text-sm mb-2">Next rank benefits:</div>
        <div className="flex items-center text-foreground text-sm">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-primary mr-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <polyline points="20 6 9 17 4 12"></polyline>
          </svg>
          Unlock higher XP rewards
        </div>
        <div className="flex items-center text-foreground text-sm mt-1.5">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-primary mr-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <polyline points="20 6 9 17 4 12"></polyline>
          </svg>
          Access more challenging missions
        </div>
      </div>
    </GlassCard>
  );
};

export default UserProfileCard;
