import React from 'react';
import { useAppContext } from '@/contexts/AppContext';
import GlassCard from '@/components/common/GlassCard';
import { MoreHorizontal, RefreshCw } from 'lucide-react';
import { motion } from 'framer-motion';

const DailyMissionsList: React.FC = () => {
  const { tasks, mentors, completeTask, resetTasks } = useAppContext();
  
  // Function to get category color
  const getCategoryColor = (category?: string) => {
    if (!category) return 'bg-primary/20 text-primary';
    
    switch (category.toLowerCase()) {
      case 'exercise':
      case 'nutrition':
      case 'wellness':
      case 'meditation':
      case 'sleep':
        return 'bg-green-600/20 text-green-400';
        
      case 'planning':
      case 'focus':
      case 'organization':
      case 'time management':
      case 'efficiency':
        return 'bg-blue-600/20 text-blue-400';
        
      case 'learning':
      case 'coding':
      case 'analysis':
      case 'research':
      case 'innovation':
        return 'bg-purple-600/20 text-purple-400';
        
      case 'mindfulness':
      case 'growth':
      case 'resilience':
      case 'positivity':
      case 'discipline':
        return 'bg-yellow-600/20 text-yellow-400';
        
      default:
        return 'bg-primary/20 text-primary';
    }
  };
  
  // Find mentor name by id
  const getMentorName = (mentorId?: string) => {
    if (!mentorId) return null;
    
    const mentor = mentors.find(m => m.id === mentorId);
    return mentor ? mentor.name : null;
  };
  
  const handleTaskComplete = (id: string) => {
    completeTask(id);
  };
  
  const handleResetTasks = () => {
    resetTasks();
  };
  
  return (
    <GlassCard className="overflow-hidden">
      <div className="p-5 border-b border-border flex items-center justify-between">
        <h2 className="text-lg font-semibold text-foreground">Daily Missions</h2>
        <span className="text-xs bg-primary/20 text-primary py-1 px-2 rounded-full">+XP per completion</span>
      </div>
      
      <div className="p-5">
        {tasks.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <p>No active missions.</p>
            <p className="text-sm mt-2">Generate new missions to start earning XP.</p>
          </div>
        ) : (
          <div className="space-y-4">
            {tasks.map((task, index) => (
              <motion.div 
                key={task.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: index * 0.1 }}
              >
                <GlassCard variant="light" className="p-4">
                  <div className="flex items-start">
                    <div className="h-5 w-5 mt-0.5 mr-3">
                      <input 
                        type="checkbox" 
                        className="h-5 w-5 rounded border-border text-primary focus:ring-primary focus:ring-offset-0 bg-background"
                        onChange={() => handleTaskComplete(task.id)}
                      />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-medium text-foreground">{task.title}</h3>
                      <p className="text-sm text-muted-foreground mt-1">{task.description}</p>
                      <div className="flex items-center mt-3">
                        <span className={`text-xs ${getCategoryColor(task.category)} py-1 px-2 rounded-full mr-2`}>
                          {task.category || 'Task'}
                        </span>
                        <span className="text-xs text-muted-foreground mr-2">
                          {task.estimatedTime || 'Flexible time'}
                        </span>
                        {task.mentorId && (
                          <span className="text-xs text-primary">
                            From: {getMentorName(task.mentorId)}
                          </span>
                        )}
                      </div>
                    </div>
                    <div className="ml-4 flex flex-col items-end">
                      <span className="text-xs font-semibold bg-secondary/10 text-secondary rounded-full px-2 py-0.5 mb-2">
                        +{task.xpReward} XP
                      </span>
                      <button className="text-muted-foreground hover:text-foreground">
                        <MoreHorizontal className="h-5 w-5" />
                      </button>
                    </div>
                  </div>
                </GlassCard>
              </motion.div>
            ))}
          </div>
        )}
        
        <button 
          className="w-full mt-6 py-2.5 bg-gradient-to-r from-primary to-secondary text-white rounded-lg font-medium hover:from-primary/90 hover:to-secondary/90 transition-all flex items-center justify-center"
          onClick={handleResetTasks}
        >
          <RefreshCw className="h-4 w-4 mr-2" />
          Generate New Missions
        </button>
      </div>
    </GlassCard>
  );
};

export default DailyMissionsList;
