import React, { useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useAppContext } from '@/contexts/AppContext';
import GlassCard from './GlassCard';
import { getRankDisplayInfo } from '@/lib/ranks';

const LevelUpModal: React.FC = () => {
  const { isLevelUpModalOpen, closeLevelUpModal, newRank, user } = useAppContext();
  
  useEffect(() => {
    if (isLevelUpModalOpen) {
      // Play sound effect (optional)
      const audio = new Audio('https://assets.mixkit.co/sfx/preview/mixkit-achievement-bell-600.mp3');
      audio.volume = 0.5;
      audio.play().catch(() => {
        // Handle potential autoplay restrictions silently
      });
    }
  }, [isLevelUpModalOpen]);
  
  if (!user) return null;
  
  const rankInfo = getRankDisplayInfo(user.selectedRankSystem, newRank);
  
  // Get a simpler rank display for the badge
  const rankDisplay = newRank.charAt(0);
  
  return (
    <AnimatePresence>
      {isLevelUpModalOpen && (
        <motion.div
          className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
        >
          {/* Background confetti effect */}
          <div id="confetti-container" className="absolute inset-0 overflow-hidden pointer-events-none" />
          
          <GlassCard className="max-w-md w-full mx-4 p-6">
            <motion.div 
              className="text-center"
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ delay: 0.2, duration: 0.5 }}
            >
              <motion.div 
                className={`mx-auto h-20 w-20 rounded-full bg-gradient-to-br from-primary-500 to-secondary-600 flex items-center justify-center text-white font-bold text-3xl mb-4`}
                initial={{ scale: 0, rotate: -180 }}
                animate={{ scale: 1, rotate: 0 }}
                transition={{ 
                  type: "spring",
                  stiffness: 260,
                  damping: 20,
                  delay: 0.3
                }}
              >
                {rankDisplay}
              </motion.div>
              
              <motion.h2 
                className="text-2xl font-bold text-white mb-2"
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.4 }}
              >
                Level Up!
              </motion.h2>
              
              <motion.p 
                className="text-gray-300 mb-6"
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.5 }}
              >
                Congratulations! You've advanced to {newRank}
              </motion.p>
              
              <motion.div 
                className="bg-gray-800/30 rounded-lg p-4 mb-6"
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.6 }}
              >
                <h3 className="text-white font-medium mb-2">New Abilities Unlocked:</h3>
                <ul className="text-sm text-gray-300 space-y-2">
                  <motion.li 
                    className="flex items-start"
                    initial={{ x: -20, opacity: 0 }}
                    animate={{ x: 0, opacity: 1 }}
                    transition={{ delay: 0.7 }}
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-primary-400 mr-2 flex-shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <polyline points="20 6 9 17 4 12"></polyline>
                    </svg>
                    <span>Increased XP rewards from tasks</span>
                  </motion.li>
                  
                  <motion.li 
                    className="flex items-start"
                    initial={{ x: -20, opacity: 0 }}
                    animate={{ x: 0, opacity: 1 }}
                    transition={{ delay: 0.8 }}
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-primary-400 mr-2 flex-shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <polyline points="20 6 9 17 4 12"></polyline>
                    </svg>
                    <span>Access to more challenging missions</span>
                  </motion.li>
                  
                  <motion.li 
                    className="flex items-start"
                    initial={{ x: -20, opacity: 0 }}
                    animate={{ x: 0, opacity: 1 }}
                    transition={{ delay: 0.9 }}
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-primary-400 mr-2 flex-shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <polyline points="20 6 9 17 4 12"></polyline>
                    </svg>
                    <span>New mentor capability options</span>
                  </motion.li>
                </ul>
              </motion.div>
              
              <motion.button 
                className="w-full py-3 bg-gradient-to-r from-primary-600 to-secondary-600 text-white rounded-lg font-medium hover:from-primary-700 hover:to-secondary-700 transition-all"
                onClick={closeLevelUpModal}
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 1 }}
                whileHover={{ scale: 1.03 }}
                whileTap={{ scale: 0.97 }}
              >
                Continue to Dashboard
              </motion.button>
            </motion.div>
          </GlassCard>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default LevelUpModal;
