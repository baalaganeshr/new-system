import React from 'react';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';

interface GlassCardProps {
  children: React.ReactNode;
  className?: string;
  variant?: 'default' | 'light' | 'dark';
  animate?: boolean;
}

const GlassCard: React.FC<GlassCardProps> = ({
  children,
  className,
  variant = 'default',
  animate = false,
}) => {
  const baseStyles = "rounded-xl backdrop-blur-lg border border-white/10";
  
  const variantStyles = {
    default: "bg-white/5 shadow-lg",
    light: "bg-white/10 shadow-md",
    dark: "bg-black/20 shadow-lg",
  };
  
  const CardComponent = animate ? motion.div : 'div';
  
  const animationProps = animate
    ? {
        initial: { opacity: 0, y: 20 },
        animate: { opacity: 1, y: 0 },
        transition: { duration: 0.3 },
      }
    : {};
  
  return (
    <CardComponent
      className={cn(baseStyles, variantStyles[variant], className)}
      {...animationProps}
    >
      {children}
    </CardComponent>
  );
};

export default GlassCard;
