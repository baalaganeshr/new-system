import React from 'react';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';

interface XpBarProps {
  currentXp: number;
  targetXp: number;
  showNumbers?: boolean;
  className?: string;
  height?: 'sm' | 'md' | 'lg';
  showAnimation?: boolean;
  rankName?: string;
}

const XpBar: React.FC<XpBarProps> = ({
  currentXp,
  targetXp,
  showNumbers = true,
  className,
  height = 'md',
  showAnimation = true,
  rankName,
}) => {
  // Calculate percentage
  const percentage = targetXp > 0 ? Math.min((currentXp / targetXp) * 100, 100) : 100;
  
  // Height classes
  const heightClasses = {
    sm: 'h-1.5',
    md: 'h-2.5',
    lg: 'h-3',
  };
  
  return (
    <div className={className}>
      {showNumbers && (
        <div className="flex justify-between text-xs mb-1">
          <span>{rankName || 'Current Level'}</span>
          <span>
            {currentXp.toLocaleString()} / {targetXp.toLocaleString()} XP
          </span>
        </div>
      )}
      <div className={cn('w-full bg-gray-700/30 rounded-full overflow-hidden', heightClasses[height])}>
        {showAnimation ? (
          <motion.div
            className="h-full bg-gradient-to-r from-primary-600 to-secondary-500 rounded-full"
            initial={{ width: 0 }}
            animate={{ width: `${percentage}%` }}
            transition={{ duration: 1, ease: 'easeOut' }}
          />
        ) : (
          <div
            className="h-full bg-gradient-to-r from-primary-600 to-secondary-500 rounded-full"
            style={{ width: `${percentage}%` }}
          />
        )}
      </div>
    </div>
  );
};

export default XpBar;
