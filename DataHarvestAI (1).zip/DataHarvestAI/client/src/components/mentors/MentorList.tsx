import React, { useState } from 'react';
import { useAppContext } from '@/contexts/AppContext';
import GlassCard from '@/components/common/GlassCard';
import { Mentor } from '@/types';
import { Edit, Trash2, ToggleLeft, ToggleRight, AlertCircle, Plus, Info } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Link } from 'wouter';
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { toast } from '@/hooks/use-toast';

interface MentorListProps {
  onEdit: (mentor: Mentor) => void;
}

const MentorList: React.FC<MentorListProps> = ({ onEdit }) => {
  const { mentors, updateMentor, deleteMentor } = useAppContext();
  
  // State for UI feedback
  const [deleteConfirmation, setDeleteConfirmation] = useState<Mentor | null>(null);
  const [actionFeedback, setActionFeedback] = useState<{id: string, action: string} | null>(null);
  const [expandedInfo, setExpandedInfo] = useState<string | null>(null);
  
  // Function to get function display name
  const getFunctionDisplayName = (func: string) => {
    switch (func) {
      case 'health': return 'Health Guide';
      case 'productivity': return 'Productivity Coach';
      case 'ai_tech': return 'AI/Tech Advisor';
      case 'mindset': return 'Mindset Coach';
      default: return func;
    }
  };
  
  // Function to get color based on personality type
  const getPersonalityColor = (type: string) => {
    switch (type) {
      case 'strict': return 'bg-red-500';
      case 'friendly': return 'bg-green-500';
      case 'brother': return 'bg-blue-500';
      case 'father': return 'bg-yellow-500';
      case 'commander': return 'bg-purple-500';
      case 'captain': return 'bg-cyan-500';
      case 'assistant': return 'bg-gray-500';
      default: return 'bg-primary';
    }
  };
  
  // Function to get gradient color based on personality
  const getPersonalityGradient = (type: string) => {
    switch (type) {
      case 'strict': return 'from-red-600 to-red-400';
      case 'friendly': return 'from-green-600 to-green-400';
      case 'brother': return 'from-blue-600 to-blue-400';
      case 'father': return 'from-yellow-600 to-yellow-400';
      case 'commander': return 'from-purple-600 to-purple-400';
      case 'captain': return 'from-cyan-600 to-cyan-400';
      case 'assistant': return 'from-gray-600 to-gray-400';
      default: return 'from-primary to-primary-foreground';
    }
  };
  
  // Toggle mentor active status with visual feedback
  const toggleMentorStatus = (mentor: Mentor) => {
    // Show action feedback
    setActionFeedback({id: mentor.id, action: 'toggle'});
    
    // After a short delay, update the mentor and clear the feedback
    setTimeout(() => {
      updateMentor({
        ...mentor,
        isActive: !mentor.isActive,
      });
      
      setActionFeedback(null);
      
      // Show toast notification
      toast({
        title: mentor.isActive ? "Mentor Deactivated" : "Mentor Activated",
        description: mentor.isActive 
          ? `${mentor.name} will no longer assign tasks.` 
          : `${mentor.name} is now active and will assign tasks.`,
      });
    }, 300);
  };
  
  // Confirm deletion
  const confirmDelete = () => {
    if (!deleteConfirmation) return;
    
    // Show action feedback
    setActionFeedback({id: deleteConfirmation.id, action: 'delete'});
    
    // After a short delay, delete the mentor and clear feedback
    setTimeout(() => {
      deleteMentor(deleteConfirmation.id);
      setDeleteConfirmation(null);
      setActionFeedback(null);
      
      // Show toast notification
      toast({
        title: "Mentor Deleted",
        description: `${deleteConfirmation.name} has been removed.`,
      });
    }, 300);
  };
  
  // Get mentor initials
  const getMentorInitials = (name: string) => {
    return name
      .split(' ')
      .map(part => part[0])
      .join('')
      .toUpperCase();
  };
  
  // Toggle expanded info panel
  const toggleExpandInfo = (mentorId: string) => {
    if (expandedInfo === mentorId) {
      setExpandedInfo(null);
    } else {
      setExpandedInfo(mentorId);
    }
  };
  
  // Mentor personality descriptions
  const personalityDescriptions: Record<string, string> = {
    strict: 'Demanding and disciplined, focused on high standards and pushing limits.',
    friendly: 'Supportive and encouraging, emphasizing positive reinforcement.',
    brother: 'Relatable peer mentor who understands challenges through shared experience.',
    father: 'Wise and nurturing, providing guidance with patience and understanding.',
    commander: 'Direct and authoritative, emphasizing excellence and precision.',
    captain: 'Team-oriented leader who motivates through example and coordination.',
    assistant: 'Helpful and efficient, focused on smooth operations and organization.'
  };
  
  // Function descriptions
  const functionDescriptions: Record<string, string> = {
    health: 'Focuses on physical wellbeing, nutrition, exercise, and lifestyle balance.',
    productivity: 'Helps optimize workflows, time management, and task prioritization.',
    ai_tech: 'Specializes in technology skills, learning, and digital advancement.',
    mindset: 'Concentrates on mental resilience, positive thinking, and growth mindset.'
  };
  
  // If no mentors have been created yet
  if (mentors.length === 0) {
    return (
      <GlassCard className="p-6 text-center">
        <div className="flex flex-col items-center justify-center py-8">
          <div className="rounded-full bg-primary/10 p-4 mb-4">
            <Plus className="h-8 w-8 text-primary" />
          </div>
          <h3 className="text-xl font-medium text-foreground mb-2">No Mentors Created</h3>
          <p className="text-muted-foreground mb-6 max-w-md mx-auto">
            Create your first mentor to get personalized tasks and guidance tailored to your growth journey.
          </p>
          <Link href="/mentor-creator">
            <Button 
              className="bg-primary hover:bg-primary/90 transition-all duration-300 transform hover:scale-105 active:scale-95"
            >
              <Plus className="h-4 w-4 mr-2" />
              Create Your First Mentor
            </Button>
          </Link>
        </div>
      </GlassCard>
    );
  }
  
  return (
    <>
      <div className="space-y-4">
        <AnimatePresence>
          {mentors.map((mentor, index) => (
            <motion.div
              key={mentor.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ 
                opacity: actionFeedback?.id === mentor.id && actionFeedback?.action === 'delete' ? 0 : 1, 
                y: 0,
                scale: actionFeedback?.id === mentor.id ? 0.98 : 1,
              }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3, delay: index * 0.1 }}
              className="relative"
            >
              <GlassCard className={`p-5 transition-all duration-300 ${actionFeedback?.id === mentor.id ? 'opacity-80' : ''}`}>
                <div className="flex items-center justify-between flex-wrap sm:flex-nowrap gap-3">
                  <div className="flex items-center">
                    <div 
                      className={`h-14 w-14 rounded-full bg-gradient-to-r ${getPersonalityGradient(mentor.personalityType)} 
                        flex items-center justify-center text-white text-lg font-bold mr-4
                        shadow-md border border-white/10 transition-transform duration-300
                        ${actionFeedback?.id === mentor.id ? 'animate-pulse' : 'hover:scale-110'}
                      `}
                    >
                      {getMentorInitials(mentor.name)}
                    </div>
                    <div>
                      <h3 className="font-semibold text-foreground text-lg flex items-center">
                        {mentor.name}
                        {!mentor.isActive && (
                          <span className="ml-2 text-xs bg-foreground/10 text-muted-foreground px-2 py-0.5 rounded-full">
                            Inactive
                          </span>
                        )}
                      </h3>
                      <div className="text-sm text-muted-foreground mt-0.5 flex items-center flex-wrap">
                        <span className="capitalize">{mentor.personalityType}</span> 
                        <span className="mx-1.5">•</span> 
                        <span>{getFunctionDisplayName(mentor.function)}</span>
                        <button 
                          onClick={() => toggleExpandInfo(mentor.id)}
                          className="ml-1.5 text-muted-foreground hover:text-primary transition-colors duration-200"
                          aria-label="More information"
                        >
                          <Info className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex space-x-2">
                    <button 
                      className={`p-2 text-muted-foreground rounded-md transition-all duration-200
                        ${mentor.isActive 
                          ? 'hover:text-primary hover:bg-primary/10' 
                          : 'hover:text-foreground hover:bg-foreground/5'
                        }
                      `}
                      onClick={() => toggleMentorStatus(mentor)}
                      title={mentor.isActive ? "Deactivate Mentor" : "Activate Mentor"}
                      aria-label={mentor.isActive ? "Deactivate Mentor" : "Activate Mentor"}
                    >
                      {mentor.isActive ? 
                        <ToggleRight className="h-6 w-6 text-primary" /> : 
                        <ToggleLeft className="h-6 w-6" />
                      }
                    </button>
                    <button 
                      className="p-2 text-muted-foreground hover:text-blue-500 hover:bg-blue-500/10 rounded-md transition-all duration-200"
                      onClick={() => onEdit(mentor)}
                      title="Edit Mentor"
                      aria-label="Edit Mentor"
                    >
                      <Edit className="h-6 w-6" />
                    </button>
                    <button 
                      className="p-2 text-muted-foreground hover:text-destructive hover:bg-destructive/10 rounded-md transition-all duration-200"
                      onClick={() => setDeleteConfirmation(mentor)}
                      title="Delete Mentor"
                      aria-label="Delete Mentor"
                    >
                      <Trash2 className="h-6 w-6" />
                    </button>
                  </div>
                </div>
                
                {/* Expanded Info Panel */}
                <AnimatePresence>
                  {expandedInfo === mentor.id && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      transition={{ duration: 0.3 }}
                      className="overflow-hidden"
                    >
                      <div className="mt-4 pt-4 border-t border-border/50 text-sm grid gap-4 sm:grid-cols-2">
                        <div>
                          <h4 className="font-medium text-foreground mb-1">Personality: {mentor.personalityType}</h4>
                          <p className="text-muted-foreground">
                            {personalityDescriptions[mentor.personalityType] || 
                              "This mentor has a unique personality style."}
                          </p>
                        </div>
                        <div>
                          <h4 className="font-medium text-foreground mb-1">Function: {getFunctionDisplayName(mentor.function)}</h4>
                          <p className="text-muted-foreground">
                            {functionDescriptions[mentor.function] || 
                              "This mentor specializes in a custom domain."}
                          </p>
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </GlassCard>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
      
      {/* Delete Confirmation Dialog */}
      <Dialog open={!!deleteConfirmation} onOpenChange={(open) => !open && setDeleteConfirmation(null)}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center">
              <AlertCircle className="h-5 w-5 text-destructive mr-2" />
              Confirm Mentor Deletion
            </DialogTitle>
            <DialogDescription>
              Are you sure you want to delete {deleteConfirmation?.name}? This action cannot be undone, and any associated tasks will lose their mentor association.
            </DialogDescription>
          </DialogHeader>
          
          {deleteConfirmation && (
            <div className="p-3 border border-border rounded-md bg-background/50 my-2 flex items-center">
              <div className={`h-10 w-10 rounded-full ${getPersonalityColor(deleteConfirmation.personalityType)} flex items-center justify-center text-white text-base font-bold mr-3`}>
                {getMentorInitials(deleteConfirmation.name)}
              </div>
              <div>
                <div className="font-medium">{deleteConfirmation.name}</div>
                <div className="text-xs text-muted-foreground">
                  {getFunctionDisplayName(deleteConfirmation.function)}
                </div>
              </div>
            </div>
          )}
          
          <DialogFooter className="flex space-x-2 sm:space-x-0">
            <Button
              variant="outline"
              onClick={() => setDeleteConfirmation(null)}
              className="transition-all duration-300"
            >
              Cancel
            </Button>
            <Button
              variant="destructive"
              onClick={confirmDelete}
              className="transition-all duration-300"
            >
              Delete Mentor
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default MentorList;
