import React, { useState } from 'react';
import { useAppContext } from '@/contexts/AppContext';
import GlassCard from '@/components/common/GlassCard';
import { PersonalityType, MentorFunction, Mentor } from '@/types';
import { motion } from 'framer-motion';
import { UserCheck } from 'lucide-react';

interface MentorFormProps {
  mentor?: Mentor;
  onCancel: () => void;
}

const MentorForm: React.FC<MentorFormProps> = ({ mentor, onCancel }) => {
  const { addMentor, updateMentor } = useAppContext();
  
  const [name, setName] = useState(mentor?.name || '');
  const [personalityType, setPersonalityType] = useState<PersonalityType>(
    mentor?.personalityType || 'friendly'
  );
  const [mentorFunction, setMentorFunction] = useState<MentorFunction>(
    mentor?.function || 'productivity'
  );
  const [isActive, setIsActive] = useState(mentor?.isActive ?? true);
  
  const personalityTypes: { value: PersonalityType; label: string; description: string }[] = [
    { 
      value: 'strict', 
      label: 'Strict', 
      description: 'Firm, disciplined, focuses on results and high standards' 
    },
    { 
      value: 'friendly', 
      label: 'Friendly', 
      description: 'Supportive, encouraging, and focuses on positive reinforcement' 
    },
    { 
      value: 'brother', 
      label: 'Brother', 
      description: 'Casual, relatable, offers guidance as a peer' 
    },
    { 
      value: 'father', 
      label: 'Father', 
      description: 'Wise, nurturing, provides life lessons and wisdom' 
    },
    { 
      value: 'commander', 
      label: 'Commander', 
      description: 'Strategic, direct, focused on mission accomplishment' 
    },
    { 
      value: 'captain', 
      label: 'Captain', 
      description: 'Team-oriented, focuses on leadership and group success' 
    },
    { 
      value: 'assistant', 
      label: 'Assistant', 
      description: 'Analytical, data-driven, objective and practical' 
    },
  ];
  
  const functionTypes: { value: MentorFunction; label: string; description: string }[] = [
    { 
      value: 'health', 
      label: 'Health Guide', 
      description: 'Focuses on physical wellbeing, fitness, nutrition, and healthy habits' 
    },
    { 
      value: 'productivity', 
      label: 'Productivity Coach', 
      description: 'Helps with organization, time management, and goal achievement' 
    },
    { 
      value: 'ai_tech', 
      label: 'AI/Tech Advisor', 
      description: 'Guides on technology, learning, and digital skills' 
    },
    { 
      value: 'mindset', 
      label: 'Mindset Coach', 
      description: 'Focuses on mental strength, positive thinking, and resilience' 
    },
  ];
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (name.trim() === '') return;
    
    if (mentor) {
      // Update existing mentor
      updateMentor({
        ...mentor,
        name,
        personalityType,
        function: mentorFunction,
        isActive,
      });
    } else {
      // Add new mentor
      addMentor({
        name,
        personalityType,
        function: mentorFunction,
        isActive,
      });
    }
    
    onCancel(); // Close form after submission
  };
  
  return (
    <GlassCard className="p-6">
      <h2 className="text-xl font-semibold text-foreground mb-4 flex items-center">
        <UserCheck className="h-5 w-5 mr-2 text-primary" />
        {mentor ? 'Edit Mentor' : 'Create New Mentor'}
      </h2>
      
      <form onSubmit={handleSubmit}>
        <div className="mb-4">
          <label className="block text-sm font-medium text-foreground mb-1">
            Mentor Name
          </label>
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="w-full px-3 py-2 bg-background border border-border rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
            placeholder="Enter mentor name"
            required
          />
        </div>
        
        <div className="mb-4">
          <label className="block text-sm font-medium text-foreground mb-2">
            Personality Type
          </label>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {personalityTypes.map((type) => (
              <div
                key={type.value}
                className={`border rounded-lg p-3 cursor-pointer transition-colors ${
                  personalityType === type.value
                    ? 'border-primary bg-primary/10'
                    : 'border-border hover:border-primary/30'
                }`}
                onClick={() => setPersonalityType(type.value)}
              >
                <div className="flex items-center">
                  <input
                    type="radio"
                    name="personalityType"
                    checked={personalityType === type.value}
                    onChange={() => {}}
                    className="h-4 w-4 text-primary"
                  />
                  <span className="ml-2 font-medium text-foreground">{type.label}</span>
                </div>
                <p className="mt-1 text-xs text-muted-foreground">{type.description}</p>
              </div>
            ))}
          </div>
        </div>
        
        <div className="mb-4">
          <label className="block text-sm font-medium text-foreground mb-2">
            Function
          </label>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {functionTypes.map((type) => (
              <div
                key={type.value}
                className={`border rounded-lg p-3 cursor-pointer transition-colors ${
                  mentorFunction === type.value
                    ? 'border-primary bg-primary/10'
                    : 'border-border hover:border-primary/30'
                }`}
                onClick={() => setMentorFunction(type.value)}
              >
                <div className="flex items-center">
                  <input
                    type="radio"
                    name="functionType"
                    checked={mentorFunction === type.value}
                    onChange={() => {}}
                    className="h-4 w-4 text-primary"
                  />
                  <span className="ml-2 font-medium text-foreground">{type.label}</span>
                </div>
                <p className="mt-1 text-xs text-muted-foreground">{type.description}</p>
              </div>
            ))}
          </div>
        </div>
        
        <div className="mb-6">
          <label className="flex items-center">
            <input
              type="checkbox"
              checked={isActive}
              onChange={() => setIsActive(!isActive)}
              className="h-4 w-4 text-primary rounded border-border focus:ring-primary"
            />
            <span className="ml-2 text-foreground">Active Mentor (will provide tasks and messages)</span>
          </label>
        </div>
        
        <div className="flex justify-end space-x-3">
          <button
            type="button"
            onClick={onCancel}
            className="px-4 py-2 border border-border text-foreground rounded-md hover:bg-border/10"
          >
            Cancel
          </button>
          <button
            type="submit"
            className="px-4 py-2 bg-primary text-white rounded-md hover:bg-primary/90"
          >
            {mentor ? 'Update Mentor' : 'Create Mentor'}
          </button>
        </div>
      </form>
    </GlassCard>
  );
};

export default MentorForm;
