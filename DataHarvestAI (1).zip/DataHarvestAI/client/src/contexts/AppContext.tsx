import React, { createContext, useContext, useState, useEffect } from 'react';
import { v4 as uuidv4 } from 'uuid';
import { format } from 'date-fns';
import {
  AppContextType,
  User,
  Mentor,
  Task,
  Rule,
  MentorMessage,
  LogEntry,
  ProgressData,
  RankSystemType,
  ResponseMode,
  ThemeType,
} from '../types';
import { getRankDetails, calculateXp } from '../lib/ranks';
import { generateMentorMessage } from '../lib/mentorMessages';
import { generateMissions } from '../lib/missions';

// Create a default context
const defaultContext: AppContextType = {
  user: null,
  mentors: [],
  tasks: [],
  completedTasks: [],
  rules: [],
  mentorMessages: [],
  logs: [],
  progressData: [],
  isLevelUpModalOpen: false,
  newRank: '',
  theme: 'dark',
  setUser: () => {},
  updateUserName: () => {},
  updateRankSystem: () => {},
  updateResponseMode: () => {},
  addMentor: () => {},
  updateMentor: () => {},
  deleteMentor: () => {},
  addTask: () => {},
  completeTask: () => {},
  resetTasks: () => {},
  addRule: () => {},
  updateRule: () => {},
  deleteRule: () => {},
  closeLevelUpModal: () => {},
  toggleTheme: () => {},
};

const AppContext = createContext<AppContextType>(defaultContext);

export const useAppContext = () => useContext(AppContext);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Load data from localStorage on component mount
  const [user, setUser] = useState<User | null>(() => {
    const savedUser = localStorage.getItem('soloLeveling_user');
    return savedUser
      ? JSON.parse(savedUser)
      : null;
  });
  
  const [mentors, setMentors] = useState<Mentor[]>(() => {
    const savedMentors = localStorage.getItem('soloLeveling_mentors');
    return savedMentors ? JSON.parse(savedMentors) : [];
  });
  
  const [tasks, setTasks] = useState<Task[]>(() => {
    const savedTasks = localStorage.getItem('soloLeveling_tasks');
    return savedTasks ? JSON.parse(savedTasks) : [];
  });
  
  const [completedTasks, setCompletedTasks] = useState<Task[]>(() => {
    const savedCompletedTasks = localStorage.getItem('soloLeveling_completedTasks');
    return savedCompletedTasks ? JSON.parse(savedCompletedTasks) : [];
  });
  
  const [rules, setRules] = useState<Rule[]>(() => {
    const savedRules = localStorage.getItem('soloLeveling_rules');
    return savedRules ? JSON.parse(savedRules) : [];
  });
  
  const [mentorMessages, setMentorMessages] = useState<MentorMessage[]>(() => {
    const savedMessages = localStorage.getItem('soloLeveling_mentorMessages');
    return savedMessages ? JSON.parse(savedMessages) : [];
  });
  
  const [logs, setLogs] = useState<LogEntry[]>(() => {
    const savedLogs = localStorage.getItem('soloLeveling_logs');
    return savedLogs ? JSON.parse(savedLogs) : [];
  });
  
  const [progressData, setProgressData] = useState<ProgressData[]>(() => {
    const savedProgressData = localStorage.getItem('soloLeveling_progressData');
    return savedProgressData ? JSON.parse(savedProgressData) : [];
  });
  
  const [isLevelUpModalOpen, setIsLevelUpModalOpen] = useState(false);
  const [newRank, setNewRank] = useState('');
  const [theme, setTheme] = useState<ThemeType>(() => {
    const savedTheme = localStorage.getItem('soloLeveling_theme');
    return savedTheme ? (savedTheme as ThemeType) : 'dark';
  });

  // Save data to localStorage whenever it changes
  useEffect(() => {
    if (user) localStorage.setItem('soloLeveling_user', JSON.stringify(user));
  }, [user]);

  useEffect(() => {
    localStorage.setItem('soloLeveling_mentors', JSON.stringify(mentors));
  }, [mentors]);

  useEffect(() => {
    localStorage.setItem('soloLeveling_tasks', JSON.stringify(tasks));
  }, [tasks]);

  useEffect(() => {
    localStorage.setItem('soloLeveling_completedTasks', JSON.stringify(completedTasks));
  }, [completedTasks]);

  useEffect(() => {
    localStorage.setItem('soloLeveling_rules', JSON.stringify(rules));
  }, [rules]);

  useEffect(() => {
    localStorage.setItem('soloLeveling_mentorMessages', JSON.stringify(mentorMessages));
  }, [mentorMessages]);

  useEffect(() => {
    localStorage.setItem('soloLeveling_logs', JSON.stringify(logs));
  }, [logs]);

  useEffect(() => {
    localStorage.setItem('soloLeveling_progressData', JSON.stringify(progressData));
  }, [progressData]);

  useEffect(() => {
    localStorage.setItem('soloLeveling_theme', theme);
    document.documentElement.classList.toggle('dark', theme === 'dark');
  }, [theme]);

  // Update user name
  const updateUserName = (name: string) => {
    if (user) {
      setUser({
        ...user,
        displayName: name,
      });
    }
  };

  // Update rank system
  const updateRankSystem = (system: RankSystemType) => {
    if (user) {
      // Reset rank and XP when changing systems
      const rankDetails = getRankDetails(system, 0, 0);
      setUser({
        ...user,
        selectedRankSystem: system,
        currentRank: rankDetails.currentRank,
        currentXp: 0,
        targetXp: rankDetails.targetXp,
      });
    }
  };

  // Update response mode
  const updateResponseMode = (mode: ResponseMode) => {
    if (user) {
      setUser({
        ...user,
        responseMode: mode,
      });
    }
  };

  // Add a new mentor
  const addMentor = (mentor: Omit<Mentor, 'id' | 'createdAt'>) => {
    const newMentor: Mentor = {
      ...mentor,
      id: uuidv4(),
      createdAt: new Date().toISOString(),
    };
    setMentors([...mentors, newMentor]);

    // Generate a welcome message from the new mentor
    addMentorMessage(newMentor.id, newMentor.name, newMentor.personalityType);
  };

  // Update an existing mentor
  const updateMentor = (updatedMentor: Mentor) => {
    setMentors(
      mentors.map((mentor) => 
        mentor.id === updatedMentor.id ? updatedMentor : mentor
      )
    );
  };

  // Delete a mentor
  const deleteMentor = (id: string) => {
    setMentors(mentors.filter((mentor) => mentor.id !== id));
  };

  // Add a new task
  const addTask = (task: Omit<Task, 'id' | 'isCompleted' | 'completedAt' | 'createdAt'>) => {
    const newTask: Task = {
      ...task,
      id: uuidv4(),
      isCompleted: false,
      createdAt: new Date().toISOString(),
    };
    setTasks([...tasks, newTask]);
  };

  // Complete a task and gain XP
  const completeTask = (id: string) => {
    if (!user) return;

    const taskToComplete = tasks.find((task) => task.id === id);
    
    if (taskToComplete) {
      // Mark task as completed
      const now = new Date().toISOString();
      const completedTask = {
        ...taskToComplete,
        isCompleted: true,
        completedAt: now,
      };
      
      // Update lists
      setTasks(tasks.filter((task) => task.id !== id));
      setCompletedTasks([completedTask, ...completedTasks]);
      
      // Add to logs
      const mentor = taskToComplete.mentorId 
        ? mentors.find((m) => m.id === taskToComplete.mentorId)
        : undefined;
        
      const newLog: LogEntry = {
        id: uuidv4(),
        taskId: taskToComplete.id,
        taskTitle: taskToComplete.title,
        xpGained: taskToComplete.xpReward,
        completedAt: now,
        mentorId: mentor?.id,
        mentorName: mentor?.name,
      };
      setLogs([newLog, ...logs]);
      
      // Add to progress data
      const today = format(new Date(), 'yyyy-MM-dd');
      const existingProgress = progressData.find((progress) => progress.date === today);
      
      if (existingProgress) {
        setProgressData(
          progressData.map((progress) =>
            progress.date === today
              ? {
                  ...progress,
                  xpGained: progress.xpGained + taskToComplete.xpReward,
                  tasksCompleted: progress.tasksCompleted + 1,
                }
              : progress
          )
        );
      } else {
        const newProgress: ProgressData = {
          date: today,
          xpGained: taskToComplete.xpReward,
          tasksCompleted: 1,
        };
        setProgressData([...progressData, newProgress]);
      }
      
      // Update user XP and check for level up
      const newXp = user.currentXp + taskToComplete.xpReward;
      const { currentRank, targetXp, hasLeveledUp } = calculateXp(
        user.selectedRankSystem,
        user.currentRank,
        newXp
      );
      
      setUser({
        ...user,
        currentXp: newXp,
        currentRank,
        targetXp,
      });
      
      // Generate mentor message
      if (taskToComplete.mentorId) {
        const mentor = mentors.find((m) => m.id === taskToComplete.mentorId);
        if (mentor) {
          addMentorMessage(mentor.id, mentor.name, mentor.personalityType);
        }
      }
      
      // Show level up modal if user has leveled up
      if (hasLeveledUp) {
        setNewRank(currentRank);
        setIsLevelUpModalOpen(true);
      }
    }
  };

  // Reset daily tasks
  const resetTasks = () => {
    // Generate new missions based on available mentors
    const newTasks = generateMissions(mentors);
    setTasks(newTasks);
  };

  // Add a mentor message
  const addMentorMessage = (mentorId: string, mentorName: string, personalityType: string) => {
    const newMessage: MentorMessage = {
      id: uuidv4(),
      mentorId,
      mentorName,
      mentorPersonality: personalityType as any,
      message: generateMentorMessage(personalityType as any, user?.responseMode || 'mixed'),
      isRead: false,
      createdAt: new Date().toISOString(),
    };
    setMentorMessages([newMessage, ...mentorMessages]);
  };

  // Add a new rule
  const addRule = (rule: Omit<Rule, 'id' | 'createdAt'>) => {
    const newRule: Rule = {
      ...rule,
      id: uuidv4(),
      createdAt: new Date().toISOString(),
    };
    setRules([...rules, newRule]);
  };

  // Update an existing rule
  const updateRule = (updatedRule: Rule) => {
    setRules(
      rules.map((rule) => 
        rule.id === updatedRule.id ? updatedRule : rule
      )
    );
  };

  // Delete a rule
  const deleteRule = (id: string) => {
    setRules(rules.filter((rule) => rule.id !== id));
  };

  // Close level up modal
  const closeLevelUpModal = () => {
    setIsLevelUpModalOpen(false);
  };

  // Toggle theme with enhanced functionality
  const toggleTheme = () => {
    const newTheme = theme === 'dark' ? 'light' : 'dark';
    setTheme(newTheme);
    
    // Apply theme class to html element
    if (newTheme === 'light') {
      document.documentElement.classList.add('light');
      document.documentElement.classList.remove('dark');
    } else {
      document.documentElement.classList.add('dark');
      document.documentElement.classList.remove('light');
    }
    
    // Add transition animation
    document.body.style.transition = 'var(--theme-transition)';
    
    // Console log for debugging
    console.log(`Theme switched to: ${newTheme}`);
  };

  const contextValue: AppContextType = {
    user,
    mentors,
    tasks,
    completedTasks,
    rules,
    mentorMessages,
    logs,
    progressData,
    isLevelUpModalOpen,
    newRank,
    theme,
    setUser,
    updateUserName,
    updateRankSystem,
    updateResponseMode,
    addMentor,
    updateMentor,
    deleteMentor,
    addTask,
    completeTask,
    resetTasks,
    addRule,
    updateRule,
    deleteRule,
    closeLevelUpModal,
    toggleTheme,
  };

  return (
    <AppContext.Provider value={contextValue}>
      {children}
    </AppContext.Provider>
  );
};
