import React, { useEffect, useState } from 'react';
import { useLocation } from 'wouter';
import { format, subDays } from 'date-fns';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  LineChart,
  Line
} from 'recharts';
import PageLayout from '@/components/layout/PageLayout';
import { useAppContext } from '@/contexts/AppContext';
import GlassCard from '@/components/common/GlassCard';
import { Button } from '@/components/ui/button';
import { BarChart2, TrendingUp, Calendar } from 'lucide-react';

const ProgressCharts: React.FC = () => {
  const { user, progressData, logs } = useAppContext();
  const [, setLocation] = useLocation();
  const [timeRange, setTimeRange] = useState<'week' | 'month'>('week');

  // If there is no user, redirect to setup
  useEffect(() => {
    if (!user) {
      setLocation('/setup');
    }
  }, [user, setLocation]);

  // Format data for charts
  const prepareChartData = () => {
    const days = timeRange === 'week' ? 7 : 30;
    const result = [];
    
    // Create array of dates for the time range
    for (let i = days - 1; i >= 0; i--) {
      const date = subDays(new Date(), i);
      const dateStr = format(date, 'yyyy-MM-dd');
      const dayData = progressData.find(d => d.date === dateStr);
      
      result.push({
        date: format(date, 'MMM dd'),
        xp: dayData ? dayData.xpGained : 0,
        tasks: dayData ? dayData.tasksCompleted : 0
      });
    }
    
    return result;
  };

  const chartData = prepareChartData();

  // Calculate category distribution
  const calculateCategoryData = () => {
    const categoryCount: Record<string, number> = {};
    
    logs.forEach(log => {
      const task = log.taskTitle.toLowerCase();
      let category = 'Other';
      
      if (task.includes('exercise') || task.includes('workout') || task.includes('fitness')) {
        category = 'Exercise';
      } else if (task.includes('learn') || task.includes('study') || task.includes('read')) {
        category = 'Learning';
      } else if (task.includes('meditation') || task.includes('mindful')) {
        category = 'Meditation';
      } else if (task.includes('coding') || task.includes('program')) {
        category = 'Coding';
      } else if (task.includes('plan') || task.includes('organize')) {
        category = 'Planning';
      }
      
      categoryCount[category] = (categoryCount[category] || 0) + 1;
    });
    
    return Object.keys(categoryCount).map(key => ({
      name: key,
      value: categoryCount[key]
    }));
  };

  if (!user) return null;

  const categoryData = calculateCategoryData();

  return (
    <PageLayout
      title="Progress Charts"
      subtitle="Visualize your growth and identify patterns in your journey"
    >
      {/* Time Range Selector */}
      <div className="flex justify-end mb-4">
        <div className="flex rounded-lg overflow-hidden border border-border">
          <Button
            variant={timeRange === 'week' ? "default" : "ghost"}
            className={timeRange === 'week' ? "rounded-none" : "rounded-none text-muted-foreground"}
            onClick={() => setTimeRange('week')}
          >
            Last Week
          </Button>
          <Button
            variant={timeRange === 'month' ? "default" : "ghost"}
            className={timeRange === 'month' ? "rounded-none" : "rounded-none text-muted-foreground"}
            onClick={() => setTimeRange('month')}
          >
            Last Month
          </Button>
        </div>
      </div>
      
      {/* XP Gained Over Time */}
      <GlassCard className="p-5 mb-6">
        <div className="flex items-center mb-4">
          <TrendingUp className="h-5 w-5 text-primary mr-2" />
          <h2 className="text-lg font-semibold text-foreground">XP Gained Over Time</h2>
        </div>
        
        <div className="h-72">
          {chartData.some(d => d.xp > 0) ? (
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                <XAxis 
                  dataKey="date" 
                  tick={{ fill: 'rgb(158, 158, 158)' }}
                  tickLine={{ stroke: 'rgb(158, 158, 158)' }}
                  axisLine={{ stroke: 'rgb(158, 158, 158)' }}
                />
                <YAxis 
                  tick={{ fill: 'rgb(158, 158, 158)' }}
                  tickLine={{ stroke: 'rgb(158, 158, 158)' }}
                  axisLine={{ stroke: 'rgb(158, 158, 158)' }}
                />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'rgba(30, 30, 45, 0.9)', 
                    borderColor: 'rgba(255, 255, 255, 0.1)',
                    color: 'white'
                  }}
                />
                <Line 
                  type="monotone" 
                  dataKey="xp" 
                  name="XP Gained"
                  stroke="hsl(var(--primary))" 
                  strokeWidth={2}
                  dot={{ fill: 'hsl(var(--primary))', r: 4 }}
                  activeDot={{ r: 6, fill: 'hsl(var(--primary))' }}
                />
              </LineChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-full flex items-center justify-center flex-col">
              <Calendar className="h-12 w-12 text-muted-foreground mb-4" />
              <p className="text-muted-foreground">No XP data available for this time period</p>
            </div>
          )}
        </div>
      </GlassCard>
      
      {/* Tasks Completed */}
      <GlassCard className="p-5 mb-6">
        <div className="flex items-center mb-4">
          <BarChart2 className="h-5 w-5 text-secondary mr-2" />
          <h2 className="text-lg font-semibold text-foreground">Tasks Completed</h2>
        </div>
        
        <div className="h-72">
          {chartData.some(d => d.tasks > 0) ? (
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                <XAxis 
                  dataKey="date" 
                  tick={{ fill: 'rgb(158, 158, 158)' }}
                  tickLine={{ stroke: 'rgb(158, 158, 158)' }}
                  axisLine={{ stroke: 'rgb(158, 158, 158)' }}
                />
                <YAxis 
                  tick={{ fill: 'rgb(158, 158, 158)' }}
                  tickLine={{ stroke: 'rgb(158, 158, 158)' }}
                  axisLine={{ stroke: 'rgb(158, 158, 158)' }}
                />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'rgba(30, 30, 45, 0.9)', 
                    borderColor: 'rgba(255, 255, 255, 0.1)',
                    color: 'white'
                  }}
                />
                <Bar 
                  dataKey="tasks" 
                  name="Tasks Completed"
                  fill="hsl(var(--secondary))" 
                  radius={[4, 4, 0, 0]}
                />
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-full flex items-center justify-center flex-col">
              <Calendar className="h-12 w-12 text-muted-foreground mb-4" />
              <p className="text-muted-foreground">No task data available for this time period</p>
            </div>
          )}
        </div>
      </GlassCard>
      
      {/* Category Distribution */}
      {categoryData.length > 0 && (
        <GlassCard className="p-5">
          <div className="flex items-center mb-4">
            <BarChart2 className="h-5 w-5 text-primary mr-2" />
            <h2 className="text-lg font-semibold text-foreground">Task Category Distribution</h2>
          </div>
          
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={categoryData} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                <XAxis 
                  type="number"
                  tick={{ fill: 'rgb(158, 158, 158)' }}
                  tickLine={{ stroke: 'rgb(158, 158, 158)' }}
                  axisLine={{ stroke: 'rgb(158, 158, 158)' }}
                />
                <YAxis 
                  dataKey="name" 
                  type="category"
                  tick={{ fill: 'rgb(158, 158, 158)' }}
                  tickLine={{ stroke: 'rgb(158, 158, 158)' }}
                  axisLine={{ stroke: 'rgb(158, 158, 158)' }}
                />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'rgba(30, 30, 45, 0.9)', 
                    borderColor: 'rgba(255, 255, 255, 0.1)',
                    color: 'white'
                  }}
                  formatter={(value) => [`${value} tasks`, 'Count']}
                />
                <Bar 
                  dataKey="value" 
                  fill="hsl(var(--chart-3))" 
                  radius={[0, 4, 4, 0]}
                />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </GlassCard>
      )}
    </PageLayout>
  );
};

export default ProgressCharts;
