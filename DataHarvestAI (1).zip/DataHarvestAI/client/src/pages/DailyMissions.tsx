import React, { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import PageLayout from '@/components/layout/PageLayout';
import MissionCard from '@/components/missions/MissionCard';
import MissionFilter from '@/components/missions/MissionFilter';
import { useAppContext } from '@/contexts/AppContext';
import { Button } from '@/components/ui/button';
import { RefreshCw, CheckSquare } from 'lucide-react';
import GlassCard from '@/components/common/GlassCard';

const DailyMissions: React.FC = () => {
  const { user, tasks, completedTasks, completeTask, resetTasks } = useAppContext();
  const [, setLocation] = useLocation();
  const [viewMode, setViewMode] = useState<'active' | 'completed'>('active');
  const [categoryFilter, setCategoryFilter] = useState<string | null>(null);
  
  // If there is no user, redirect to setup
  useEffect(() => {
    if (!user) {
      setLocation('/setup');
    }
  }, [user, setLocation]);

  // Filter tasks based on selected category
  const filteredTasks = viewMode === 'active' 
    ? tasks.filter(task => !categoryFilter || task.category === categoryFilter)
    : completedTasks.filter(task => !categoryFilter || task.category === categoryFilter);

  if (!user) return null;

  return (
    <PageLayout
      title="Daily Missions"
      subtitle="Complete tasks to gain XP and level up your skills"
    >
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
        <MissionFilter 
          viewMode={viewMode} 
          onViewModeChange={setViewMode} 
          categoryFilter={categoryFilter}
          onCategoryFilterChange={setCategoryFilter}
        />
        
        <Button 
          onClick={resetTasks}
          className="bg-gradient-to-r from-primary to-secondary text-white"
        >
          <RefreshCw className="h-4 w-4 mr-2" />
          Generate New Missions
        </Button>
      </div>

      <div className="space-y-4">
        {filteredTasks.length > 0 ? (
          filteredTasks.map(task => (
            <MissionCard 
              key={task.id} 
              task={task} 
              onComplete={completeTask} 
            />
          ))
        ) : (
          <GlassCard className="p-10 text-center">
            {viewMode === 'active' ? (
              <>
                <CheckSquare className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-xl font-medium text-foreground mb-2">No Active Missions</h3>
                <p className="text-muted-foreground mb-6">
                  You've completed all your current missions. Generate new ones to continue leveling up!
                </p>
                <Button 
                  onClick={resetTasks}
                  className="bg-primary hover:bg-primary/90"
                >
                  <RefreshCw className="h-4 w-4 mr-2" />
                  Generate New Missions
                </Button>
              </>
            ) : (
              <>
                <h3 className="text-xl font-medium text-foreground mb-2">No Completed Missions</h3>
                <p className="text-muted-foreground mb-4">
                  Once you complete missions, they will appear here.
                </p>
                <Button 
                  onClick={() => setViewMode('active')}
                  variant="outline"
                >
                  View Active Missions
                </Button>
              </>
            )}
          </GlassCard>
        )}
      </div>
    </PageLayout>
  );
};

export default DailyMissions;
