import React, { useEffect } from 'react';
import { useLocation } from 'wouter';
import PageLayout from '@/components/layout/PageLayout';
import { useAppContext } from '@/contexts/AppContext';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import UserProfileSettings from '@/components/settings/UserProfileSettings';
import RankSettings from '@/components/settings/RankSettings';
import RuleSettings from '@/components/settings/RuleSettings';
import MentorResponseSettings from '@/components/settings/MentorResponseSettings';
import { User, BadgeCheck, Scroll, MessageCircle } from 'lucide-react';

const Settings: React.FC = () => {
  const { user } = useAppContext();
  const [, setLocation] = useLocation();

  // If there is no user, redirect to setup
  useEffect(() => {
    if (!user) {
      setLocation('/setup');
    }
  }, [user, setLocation]);

  if (!user) return null;

  return (
    <PageLayout
      title="Settings"
      subtitle="Customize your experience and preferences"
    >
      <Tabs defaultValue="profile" className="w-full">
        <TabsList className="mb-6 w-full md:w-auto bg-card/30 backdrop-blur-lg rounded-lg p-1">
          <TabsTrigger value="profile" className="flex gap-1 items-center">
            <User className="h-4 w-4" />
            <span className="hidden md:inline">Profile</span>
          </TabsTrigger>
          <TabsTrigger value="rank" className="flex gap-1 items-center">
            <BadgeCheck className="h-4 w-4" />
            <span className="hidden md:inline">Rank System</span>
          </TabsTrigger>
          <TabsTrigger value="rules" className="flex gap-1 items-center">
            <Scroll className="h-4 w-4" />
            <span className="hidden md:inline">System Rules</span>
          </TabsTrigger>
          <TabsTrigger value="responses" className="flex gap-1 items-center">
            <MessageCircle className="h-4 w-4" />
            <span className="hidden md:inline">Response Mode</span>
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="profile" className="mt-0">
          <UserProfileSettings />
        </TabsContent>
        
        <TabsContent value="rank" className="mt-0">
          <RankSettings />
        </TabsContent>
        
        <TabsContent value="rules" className="mt-0">
          <RuleSettings />
        </TabsContent>
        
        <TabsContent value="responses" className="mt-0">
          <MentorResponseSettings />
        </TabsContent>
      </Tabs>
    </PageLayout>
  );
};

export default Settings;
