import React, { useEffect } from 'react';
import { useLocation } from 'wouter';
import PageLayout from '@/components/layout/PageLayout';
import ActivityList from '@/components/logbook/ActivityList';
import { useAppContext } from '@/contexts/AppContext';
import GlassCard from '@/components/common/GlassCard';
import XpBar from '@/components/common/XpBar';
import { Book, TrendingUp } from 'lucide-react';

const Logbook: React.FC = () => {
  const { user, logs, completedTasks } = useAppContext();
  const [, setLocation] = useLocation();

  // If there is no user, redirect to setup
  useEffect(() => {
    if (!user) {
      setLocation('/setup');
    }
  }, [user, setLocation]);

  // Calculate total XP gained
  const totalXp = logs.reduce((total, log) => total + log.xpGained, 0);
  
  // Get stats for today and yesterday
  const today = new Date().toISOString().split('T')[0];
  const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];
  
  const todayLogs = logs.filter(log => log.completedAt.startsWith(today));
  const yesterdayLogs = logs.filter(log => log.completedAt.startsWith(yesterday));
  
  const todayXp = todayLogs.reduce((total, log) => total + log.xpGained, 0);
  const yesterdayXp = yesterdayLogs.reduce((total, log) => total + log.xpGained, 0);

  if (!user) return null;

  return (
    <PageLayout
      title="Logbook"
      subtitle="Track your progress and review your completed missions"
    >
      {/* Stats Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <GlassCard className="p-4">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-muted-foreground text-sm font-medium">Total XP Gained</p>
              <h3 className="text-2xl font-bold text-foreground mt-1">{totalXp.toLocaleString()}</h3>
            </div>
            <div className="bg-primary/10 p-2 rounded-lg">
              <TrendingUp className="h-6 w-6 text-primary" />
            </div>
          </div>
          {user && (
            <div className="mt-3">
              <XpBar 
                currentXp={user.currentXp} 
                targetXp={user.targetXp} 
                showNumbers={false}
                height="sm"
                showAnimation={false}
              />
            </div>
          )}
        </GlassCard>
        
        <GlassCard className="p-4">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-muted-foreground text-sm font-medium">Completed Tasks</p>
              <h3 className="text-2xl font-bold text-foreground mt-1">{completedTasks.length}</h3>
            </div>
            <div className="bg-secondary/10 p-2 rounded-lg">
              <Book className="h-6 w-6 text-secondary" />
            </div>
          </div>
          <div className="mt-2 flex items-center text-xs">
            <span className="text-muted-foreground">
              {todayLogs.length} completed today
            </span>
          </div>
        </GlassCard>
        
        <GlassCard className="p-4">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-muted-foreground text-sm font-medium">Today's XP</p>
              <h3 className="text-2xl font-bold text-foreground mt-1">{todayXp}</h3>
            </div>
            <div className="bg-green-500/10 p-2 rounded-lg">
              <TrendingUp className="h-6 w-6 text-green-500" />
            </div>
          </div>
          <div className="mt-2 flex items-center text-xs">
            {yesterdayXp > 0 ? (
              <span className={`flex items-center ${todayXp > yesterdayXp ? 'text-green-400' : 'text-red-400'}`}>
                {todayXp > yesterdayXp ? (
                  <>
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <polyline points="22 7 13.5 15.5 8.5 10.5 2 17"></polyline>
                      <polyline points="16 7 22 7 22 13"></polyline>
                    </svg>
                    {Math.round((todayXp - yesterdayXp) / yesterdayXp * 100)}% compared to yesterday
                  </>
                ) : (
                  <>
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <polyline points="22 17 13.5 8.5 8.5 13.5 2 7"></polyline>
                      <polyline points="16 17 22 17 22 11"></polyline>
                    </svg>
                    {Math.round((yesterdayXp - todayXp) / yesterdayXp * 100)}% compared to yesterday
                  </>
                )}
              </span>
            ) : (
              <span className="text-muted-foreground">No data from yesterday to compare</span>
            )}
          </div>
        </GlassCard>
      </div>
      
      {/* Activity Log */}
      <GlassCard className="overflow-hidden">
        <div className="p-5 border-b border-border">
          <h2 className="text-lg font-semibold text-foreground">Activity Log</h2>
        </div>
        
        <ActivityList logs={logs} />
      </GlassCard>
    </PageLayout>
  );
};

export default Logbook;
