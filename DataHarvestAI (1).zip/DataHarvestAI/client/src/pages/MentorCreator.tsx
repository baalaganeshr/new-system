import React, { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import PageLayout from '@/components/layout/PageLayout';
import MentorList from '@/components/mentors/MentorList';
import MentorForm from '@/components/mentors/MentorForm';
import { useAppContext } from '@/contexts/AppContext';
import { Button } from '@/components/ui/button';
import { UserPlus } from 'lucide-react';
import { Mentor } from '@/types';

const MentorCreator: React.FC = () => {
  const { user, mentors } = useAppContext();
  const [, setLocation] = useLocation();
  const [showForm, setShowForm] = useState(false);
  const [editMentor, setEditMentor] = useState<Mentor | undefined>(undefined);

  // If there is no user, redirect to setup
  useEffect(() => {
    if (!user) {
      setLocation('/setup');
    }
  }, [user, setLocation]);

  const handleCreateClick = () => {
    setEditMentor(undefined);
    setShowForm(true);
  };

  const handleEditMentor = (mentor: Mentor) => {
    setEditMentor(mentor);
    setShowForm(true);
  };

  const handleCancelForm = () => {
    setShowForm(false);
    setEditMentor(undefined);
  };

  if (!user) return null;

  return (
    <PageLayout
      title="Mentor Creator"
      subtitle="Create and manage your personal mentors who will guide your journey"
    >
      <div className="mb-6 flex justify-between items-center">
        <div>
          <p className="text-muted-foreground">
            You have <span className="text-primary font-medium">{mentors.length}</span> mentor{mentors.length !== 1 ? 's' : ''}
          </p>
        </div>
        
        {!showForm && (
          <Button 
            onClick={handleCreateClick}
            className="bg-gradient-to-r from-primary to-secondary text-white"
          >
            <UserPlus className="h-4 w-4 mr-2" />
            Create New Mentor
          </Button>
        )}
      </div>

      {showForm ? (
        <MentorForm mentor={editMentor} onCancel={handleCancelForm} />
      ) : (
        <MentorList onEdit={handleEditMentor} />
      )}

      {!showForm && mentors.length === 0 && (
        <div className="text-center mt-12">
          <h3 className="text-lg font-medium text-foreground mb-2">No Mentors Yet</h3>
          <p className="text-muted-foreground mb-6 max-w-md mx-auto">
            Create your first mentor to receive personalized tasks and guidance on your leveling journey.
          </p>
          <Button 
            onClick={handleCreateClick}
            className="bg-primary hover:bg-primary/90"
          >
            <UserPlus className="h-4 w-4 mr-2" />
            Create Your First Mentor
          </Button>
        </div>
      )}
    </PageLayout>
  );
};

export default MentorCreator;
