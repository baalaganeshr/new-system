import React, { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import { motion } from 'framer-motion';
import { useAppContext } from '@/contexts/AppContext';
import GlassCard from '@/components/common/GlassCard';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { RankSystemType, ResponseMode, User } from '@/types';
import { Shield, ChevronRight, User as UserIcon } from 'lucide-react';
import { getRankDetails } from '@/lib/ranks';

const UserSetup: React.FC = () => {
  const { user, setUser } = useAppContext();
  const [, setLocation] = useLocation();
  const [name, setName] = useState('');
  const [selectedRankSystem, setSelectedRankSystem] = useState<RankSystemType>('type_a');
  const [responseMode, setResponseMode] = useState<ResponseMode>('mixed');
  
  // If user already exists, redirect to dashboard
  useEffect(() => {
    if (user) {
      setLocation('/');
    }
  }, [user, setLocation]);
  
  const rankSystems = [
    {
      id: 'type_a' as RankSystemType,
      name: 'Hunter Ranks',
      description: 'Progress from E-Rank to S-Rank with 5 levels each',
      example: 'E1 → D1 → C1 → B1 → A1 → S1',
    },
    {
      id: 'type_b' as RankSystemType,
      name: 'League System',
      description: 'Climb from Bronze to Master with tiered levels',
      example: 'Bronze I → Silver I → Gold I → Diamond I → Master',
    },
    {
      id: 'type_c' as RankSystemType,
      name: 'Level System',
      description: 'Simple level-based progression from Level 1 to 30',
      example: 'Level 1 → Level 2 → ... → Level 30',
    },
  ];
  
  const responseModes = [
    {
      id: 'strict' as ResponseMode,
      name: 'Strict',
      description: 'Focus on discipline and high standards'
    },
    {
      id: 'friendly' as ResponseMode, 
      name: 'Friendly',
      description: 'Encouraging and supportive feedback'
    },
    {
      id: 'mixed' as ResponseMode,
      name: 'Mixed',
      description: 'Balanced feedback style (recommended)'
    },
    {
      id: 'silent' as ResponseMode,
      name: 'Silent Observer',
      description: 'Minimal feedback, just track progress'
    },
  ];
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (name.trim() === '') return;
    
    // Initialize user and get rank details
    const rankDetails = getRankDetails(selectedRankSystem);
    
    const newUser: User = {
      id: '1',
      displayName: name,
      selectedRankSystem,
      currentRank: rankDetails.currentRank,
      currentXp: 0,
      responseMode,
      targetXp: rankDetails.targetXp,
    };
    
    setUser(newUser);
    setLocation('/');
  };
  
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-background p-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="mb-6 text-center"
      >
        <div className="flex justify-center mb-4">
          <Shield className="h-14 w-14 text-primary" />
        </div>
        <h1 className="text-3xl font-bold text-foreground mb-2">
          Solo Leveling System
        </h1>
        <p className="text-muted-foreground">
          Create your profile to begin your journey
        </p>
      </motion.div>
      
      <GlassCard className="w-full max-w-md p-6">
        <form onSubmit={handleSubmit}>
          <div className="space-y-6">
            <div>
              <Label htmlFor="name" className="text-foreground">
                What's your name?
              </Label>
              <div className="mt-1.5 relative">
                <UserIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                <Input
                  id="name"
                  placeholder="Enter your name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="pl-10"
                  required
                />
              </div>
              <p className="text-xs text-muted-foreground mt-1.5">
                This is how mentors will address you
              </p>
            </div>
            
            <div>
              <Label className="text-foreground mb-3 block">
                Select your rank progression system
              </Label>
              <div className="space-y-3">
                {rankSystems.map((system) => (
                  <div
                    key={system.id}
                    className={`border rounded-lg p-3 cursor-pointer transition-colors ${
                      selectedRankSystem === system.id
                        ? 'border-primary bg-primary/10'
                        : 'border-border hover:border-primary/30'
                    }`}
                    onClick={() => setSelectedRankSystem(system.id)}
                  >
                    <div className="flex items-center">
                      <input
                        type="radio"
                        name="rankSystem"
                        checked={selectedRankSystem === system.id}
                        onChange={() => {}}
                        className="h-4 w-4 text-primary rounded-full"
                      />
                      <span className="ml-2 font-medium text-foreground">{system.name}</span>
                    </div>
                    <p className="mt-1 text-xs text-muted-foreground">{system.description}</p>
                    <p className="mt-1 text-xs font-mono text-primary/70">{system.example}</p>
                  </div>
                ))}
              </div>
            </div>
            
            <div>
              <Label className="text-foreground mb-3 block">
                Choose mentor response mode
              </Label>
              <div className="grid grid-cols-2 gap-3">
                {responseModes.map((mode) => (
                  <div
                    key={mode.id}
                    className={`border rounded-lg p-3 cursor-pointer transition-colors ${
                      responseMode === mode.id
                        ? 'border-primary bg-primary/10'
                        : 'border-border hover:border-primary/30'
                    }`}
                    onClick={() => setResponseMode(mode.id)}
                  >
                    <div className="flex items-center">
                      <input
                        type="radio"
                        name="responseMode"
                        checked={responseMode === mode.id}
                        onChange={() => {}}
                        className="h-4 w-4 text-primary rounded-full"
                      />
                      <span className="ml-2 font-medium text-foreground">{mode.name}</span>
                    </div>
                    <p className="mt-1 text-xs text-muted-foreground">{mode.description}</p>
                  </div>
                ))}
              </div>
            </div>
            
            <Button
              type="submit"
              className="w-full bg-gradient-to-r from-primary to-secondary text-white"
              disabled={name.trim() === ''}
            >
              Begin Your Journey
              <ChevronRight className="h-4 w-4 ml-2" />
            </Button>
          </div>
        </form>
      </GlassCard>
      
      <p className="mt-6 text-xs text-muted-foreground text-center">
        Your data is stored locally in your browser.
        <br />
        You can change these settings later.
      </p>
    </div>
  );
};

export default UserSetup;
